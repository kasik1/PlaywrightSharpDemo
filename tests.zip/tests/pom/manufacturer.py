from selenium.webdriver.common.by import By
from .ssot import SSOTPage
from tests.pom.selectors.ssot import SSoTCManufacturers as SSoTM


class SSOTManufacturers(SSOTPage):
    """Contains the functions to run the manufacturer module"""

    def add_manufacturer(self, data):
        """Add a manufacturer ."""
        self.manufacturers_page()
        self.click_add_button()
        self.set_manufacturer_data(data)
        self.click_submit_button()

    def set_manufacturer_data(self, data):
        """Sets the data for the manufacturer's inputs."""
        self.get_element(SSoTM.name_selector)
        self.set_text(SSoTM.name_selector, data['NAME'])
        self.set_text(SSoTM.description_selector, data['DESCRIPTION'])

    def edit_manufacturer(self, name, data):
        """Edit a manufacturer."""
        _, edit, _ = self.get_manufacturer_buttons_by_name(name)
        edit.click()
        self.set_manufacturer_data(data)
        self.click_update_button()

    def delete_manufacturer(self, name):
        """Delete a manufacturer."""
        _, _, delete = self.get_manufacturer_buttons_by_name(name)
        delete.click()
        self.click_confirm_button()

    def view_first_manufacturer(self):
        locator = (By.XPATH, '//tbody/tr[1]/td[2]/a[1]')
        self.click_on_element(locator)
        return True

    def is_present_title_device_type(self):
        locator = (By.XPATH, "//strong[contains(text(),'Devices')]")
        return self.get_element(locator)

    def view_change_log(self, name):
        """Edit a manufacturer."""
        log, _, _ = self.get_manufacturer_buttons_by_name(name)
        log.click()