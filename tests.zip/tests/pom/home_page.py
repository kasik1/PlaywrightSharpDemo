from .page import Page
from selenium.webdriver.common.by import By

class HomePage(Page):
    """"SSOTPage is the class name for the module SSOT"""

    def go_to_tab(self, tab_name):
        locator = (By.XPATH, f"//ul/li[@role='presentation']/a[text()='{tab_name}']")
        self.click_on_element(locator)
