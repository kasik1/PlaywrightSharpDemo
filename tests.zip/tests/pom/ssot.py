import os, glob
import time

from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.color import Color
from .page import Page
import csv
import string
import random

from ..pom.selectors.ssot import SSoT, \
    SSoTDevices as SSoTD, SSoTTenantGroup as SSoTTG, \
    SSoTLocations as SSoTS,  \
    SSoTPlatform as SSoTPlat


class SSOTPage(Page):
    """"SSOTPage is the class name for the module SSOT"""

    def go_to_tab(self, tab_name):
        locator = (By.XPATH, f"//ul/li[@role='presentation']/a[contains(text(),'{tab_name}')]")
        self.click_on_element(locator)

    def is_log_table_present(self):
        locator = (By.XPATH, f"//thead/tr/th[contains(text(), 'Request ID')]")
        return self.get_element(locator)

    def is_title_present(self, text, type='h1', timeout=30):
        locator = (By.XPATH, f"//{type}[contains(text(), '{text}')]")
        return self.get_element(locator, timeout=timeout)

    def organization_menu(self):
        """Clicks in the Organization Menu"""
        self.get_element(SSoT.organization_menu_selector, timeout=30)
        selector = SSoT.organization_menu_selector
        self.click_on_element(selector)

    def devices_menu(self):
        """Clicks in the Devices Menu"""
        self.get_element(SSoT.devices_menu_selector, timeout=30)
        selector = SSoT.devices_menu_selector
        self.click_on_element(selector)

    def circuits_menu(self):
        self.get_element(SSoT.circuits_menu, timeout=20)
        self.click_on_element(SSoT.circuits_menu)

    def ipam_menu(self):
        self.get_element(SSoT.ipam_menu, timeout=20)
        self.click_on_element(SSoT.ipam_menu)

    def plugins_menu(self):
        """Clicks in the Organization Menu"""
        self.get_element(SSoT.plugins_menu, timeout=30)
        selector = SSoT.plugins_menu
        self.click_on_element(selector)

    def device_cycle_menu(self):
        """Clicks in the Organization Menu"""
        self.get_element(SSoT.devices_lifecycle_menu_selector, timeout=30)
        selector = SSoT.devices_lifecycle_menu_selector
        self.click_on_element(selector)

    def jobs_menu(self):
        """Clicks in the Organization Menu"""
        self.get_element(SSoT.jobs_menu_selector, timeout=30)
        selector = SSoT.jobs_menu_selector
        self.click_on_element(selector)

    def apps_menu(self):
        """Clicks in the Organization Menu"""
        time.sleep(2)
        self.get_element(SSoT.apps_menu, timeout=70)
        self.click_on_element(SSoT.apps_menu, timeout=30)

    def manufacturers_page(self):
        """Gets the manufacturers page."""
        selector = SSoT.manufacturers_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.devices_menu()
            self.click_on_element(selector)
        self.get_title_module("Manufacturers")

    def locations_page(self):
        """Gets the sites page."""
        selector = SSoT.location_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.organization_menu()
            self.click_on_element(selector)
        self.get_title_module("Locations")

    def regions_page(self):
        """Gets the regions page."""
        self.organization_menu()
        selector = SSoT.regions_menu_selector
        self.click_on_element(selector)

    def racks_page(self):
        """Gets the racks page."""
        selector = SSoT.racks_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.organization_menu()
            self.click_on_element(selector)
        self.get_title_module("Racks")

    def rack_roles_page(self):
        """Gets the rack roles page."""
        selector = SSoT.rack_roles_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.organization_menu()
            self.click_on_element(selector)
        self.get_title_module("Rack Roles")

    def rack_groups_page(self):
        """Gets the rack roles page."""
        selector = SSoT.rack_groups_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.organization_menu()
            self.click_on_element(selector)
        self.get_title_module("Locations")

    def virtual_chassis_page(self):
        self.devices_menu()
        selector = SSoT.virtual_chass

        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.devices_menu()
            self.click_on_element(selector)
        self.get_title_module("Virtual Chassis")

    def platform_page(self):
        selector = SSoT.platform_link
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.devices_menu()
            self.click_on_element(selector)

    def contracts_page(self):
        """Gets the contacts page."""
        selector = SSoT.contracts_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.device_cycle_menu()
            self.click_on_element(selector)
        self.get_title_module("Contracts")

    def device_indicators_page(self):
        """Gets the device indicators page."""
        selector = SSoT.device_indicator_menu_selector
        element = self.get_element(selector, timeout=60)
        if element.is_displayed():
            self.click_on_element(selector)
        else:
            self.apps_menu()
            self.click_on_element_by_js(selector)
            self.get_title_module("Device Indicator")

    def installed_apps_page(self):
        """Gets the installed apps page."""
        selector = SSoT.installed_apps_menu_selector
        element = self.get_element(selector)
        if element.is_displayed():
            self.click_on_element(selector)
        else:
            self.apps_menu()
            self.click_on_element(selector)
            self.get_title_module("Installed Apps")

    def check_headers_table(self, headers):
        for text in headers:
            locator = (By.XPATH, f"//th/a[text()='{text}']")
            return self.is_element_present(locator)

    def select_device_checkbox(self):
        selector = SSoTD.devices_first_check_box
        self.click_on_element(selector)

    def device_types_page(self):
        """Gets the device types page."""
        selector = SSoT.devices_types_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.devices_menu()
            self.click_on_element(selector)

    def roles_page(self):
        """Gets the roles page."""
        selector = SSoT.roles_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.devices_menu()
            self.click_on_element(selector)

    def tenant_group_page(self):
        """Gets the tenant group types page."""
        selector = SSoT.tenant_group_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.organization_menu()
            self.click_on_element(selector)
        self.get_title_module("Tenant Groups")

    def tenant_page(self):
        """Gets the tenant group types page."""
        selector = SSoT.tenant_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.organization_menu()
            self.click_on_element(selector)
        self.get_title_module("Tenants")

    def devices_page(self):
        """Gets the devices page."""
        selector = SSoT.devices_menu_selector_submenu
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.devices_menu()
            self.click_on_element(selector)
        self.get_title_module("Devices")

    def inventory_items_page(self):
        """Goes to the Inventory Item page"""
        selector = SSoT.inventory_page_menu_selector

        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.devices_menu()
            self.click_on_element(selector)
        self.get_title_module("Inventory Items")

    def page_snow(self):
        selector = SSoT.page_snow

        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.click_on_element(SSoT.plugins_menu)
            self.click_on_element(selector)
        self.get_title_module("Service Now Device Requests")

    def circuits_page(self):
        selector = SSoT.page_circuits
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.circuits_menu()
            self.click_on_element(selector)
        self.get_title_module("Circuits")

    def providers_page(self):
        selector = SSoT.page_providers
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.circuits_menu()
            self.click_on_element(selector)
        self.get_title_module("Providers")

    def circuit_types_page(self):
        selector = SSoT.page_circuit_types
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.circuits_menu()
            self.click_on_element(selector)
        self.get_title_module("Circuit Types")

    def ip_addresses_page(self):
        selector = SSoT.ip_addresses
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.ipam_menu()
            self.click_on_element(selector)
        self.get_title_module("IP Addresses")

    def job_results_page(self):
        selector = SSoT.job_results_menu
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.jobs_menu()
            self.click_on_element(selector)
        self.get_title_module("Job Results")

    def inventory_list_page(self):
        selector = SSoT.inventory_list_page
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.apps_menu()
            self.click_on_element(selector)
        self.get_title_module("Devices")

    def stag_list_page(self):
        selector = SSoT.stag_inventory_list_page
        element = self.get_element(selector)
        if element.is_displayed():
            self.click_on_element(selector)
        else:
            self.apps_menu()
            self.click_on_element(selector)
        self.get_title_module("Devices")

    def bulk_snow_page(self):
        selector = SSoT.bulk_snow_page
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.apps_menu()
            self.click_on_element(selector)
        self.get_title_module("ServiceNow Bulk Devices")

    def partial_discovery_page(self):
        selector = SSoT.partial_discover_page
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.apps_menu()
            self.click_on_element(selector)
            self.get_title_module("IP Fabric Partial Discovery")

    def device_bulk(self):
        selector = SSoT.device_bulk
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.apps_menu()
            self.click_on_element(selector)
        self.get_title_module("Device Bulk Import")

    def click_add_button(self):
        """Clicks add button"""
        self.get_element(SSoT.add_contact_selector)
        self.click_on_element(SSoT.add_contact_selector)

    def click_export_button(self):
        """ Click in export button in all modules"""
        element = self.get_element((By.XPATH, "//a[@id='button_add']/../div/button"))
        element.click()

    def click_export_with_two_buttons(self):
        element = self.get_element((By.XPATH, "//button[contains(@class, 'btn btn-success')]"))
        element.click()

        """ Click in export button in all modules"""
    def click_table_edit_button(self):
        """ Clicks edit button """
        element = self.get_element((By.XPATH,
                                    "//div[@class='bulk-button-group']/button[@type='submit'][@name='_edit']"))
        element.send_keys(Keys.END)
        element.click()

    def click_table_delete_button(self):
        """ Clicks delete button """
        element = self.get_element((By.XPATH,
                                    "//div[@class='bulk-button-group']/button[@type='submit'][@name='_delete']"))
        element.send_keys(Keys.END)
        element.click()

    def submit_csv(self):
        locator = (By.XPATH, "//div[@class='form-group']//button[@type='submit']")
        self.get_element(locator)
        self.click_on_element(locator)

    def click_submit_button(self):
        """Clicks submit button"""
        self.get_element(SSoT.submit_button_selector)
        self.click_on_element_by_js(SSoT.submit_button_selector)

    def click_update_button(self):
        """Clicks update button"""
        self.get_element(SSoT.update_button_selector)
        self.click_on_element(SSoT.update_button_selector)

    def click_confirm_button(self):
        """Clicks confirm button"""
        self.get_element(SSoT.confirm_button_selector)
        self.click_on_element(SSoT.confirm_button_selector)

    def click_inventory_tab(self):
        """Clicks confirm button"""
        self.get_element(SSoT.add_components)
        self.click_on_element(SSoT.add_components)
        self.click_on_element((By.XPATH, "//button[@id='add-device-components']"
                                         "/following-sibling::ul/li/a[contains(text(),'Inventory Items')]"))

    def export_current_view(self):
        element = self.get_element((By.XPATH, "//a[contains(@class, 'btn btn-success')]"))
        element.click()
        time.sleep(1)
        Keys.ENTER

    def get_data_for_check_export(self, row):
        locator = (By.XPATH, f"//table[1]/tbody[1]/tr/td[{row}]")
        elements = self.get_elements(locator)
        elements = [element.text for element in elements]
        return elements

    def read_csv(self,file_name):
        """ Validate CSV content """
        path = os.getcwd()
        array = []
        file_path = os.path.join(path, file_name)
        with open(file_path, newline='') as f:
            reader = csv.reader(f)
            for line in list(reader):
                array = line + array
            return array

    def check_csv_and_data(self, data, csv):
        return all(element in csv for element in data)

    def alert_is_present(self):
        """Check if the alert is present."""
        selector = SSoT.alert_success_selector
        return self.is_element_present(selector)

    def check_url(self, url):
        """Check the UI is the expected."""
        current_url = self.get_url()
        return url in current_url

    def check_alert_text(self, message, timeout=60):
        """Check if the text alert is the expected."""
        selector = SSoT.alert_success_selector
        return self.text_in_element(selector, message, timeout)

    def error_alert_is_present(self, message=None):
        """Check if the text alert is the expected."""
        selector = SSoT.alert_error_selector
        element = self.is_element_present(selector)
        if message:
            element = self.text_in_element(selector, message, timeout=25)
        return element

    def set_textarea(self, text):
        selector = (By.ID, 'id_csv')
        self.set_text(selector, text)

    def clear_textarea(self):
        selector = (By.ID, 'id_csv')
        element = self.get_element(selector)
        element.clear()

    def click_by_text(self, text):
        """Chick in a element by link text."""
        selector = self.get_format_selector(selector=SSoT.link_selector, item=text)
        self.click_on_element(selector)

    def click_link_text(self, text):
        """Click in a element by text, this is useful for links in a table."""
        self.click_by_text(text)

    def click_edit_button(self):
        """Click in the edit button."""
        self.click_on_element(SSoT.edit_button)

    def click_delete_button(self):
        """Click in the delete button."""
        self.click_on_element(SSoT.action_drop)
        self.click_on_element(SSoT.delete_button)

    def click_tenant(self):
        self.click_on_element(SSoTTG.edit_tenant_group)

    def set_select_data(self, select, data):
        """Set a selector from data."""
        if data != " ":
            if data != "":
                self.get_elements(select)
                self.click_on_element(select)

                if data in ['Test-Rack 01', '', 'INTERFACE_NAME', 'test vendor', 'Hardware']:
                    option_locator = (By.XPATH, "//option[contains(text(), '" + data + "')]")
                    li_locator = (By.XPATH, "//li[contains(text(), '" + data + "')]")
                    if self.is_element_present(SSoT.select_search_selector):
                        self.set_text(SSoT.select_search_selector, data, enter=False, ssot_wait=True)
                        time.sleep(2)
                        self.get_element(li_locator).click()
                    else:
                        self.get_element(option_locator)
                        self.click_on_element(option_locator)

                else:
                    self.set_text(SSoT.select_search_selector, data, enter=False, ssot_wait=True)
                    time.sleep(2)
                    option_locator_li = (By.XPATH, "//li[@class ='select2-results__option select2-results__option--highlighted' and contains(text(), '" + data + "')]")
                    self.get_element(option_locator_li)
                    self.click_on_element(option_locator_li)

    def set_select_data_for_search(self, select_locator, option):
        self.click_on_element(select_locator)
        locator = (By.XPATH, f"//select[@id='{select_locator[1]}']/..//input")
        self.set_text(locator, option, enter=True, ssot_wait=True)

    def add_component(self, name):
        """Add a component."""
        SSoT_devices = SSoTD()
        selector = SSoT_devices.add_component_button
        self.click_on_element(selector)
        SSoT_devices.set_value(name)
        locator = SSoT_devices.components_option
        self.click_on_element(locator)

    def get_manufacturer_buttons_by_name(self, name):
        """Gets the button edit and delete from manufacturers table."""
        self.manufacturers_page()
        self.input_search_filters(name)
        self.search_button_filters()
        try:
            rows = self.get_elements(SSoT.rows_selector)
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                check, td_name, _, _, _, description, buttons = (list(columns))[:7]
                if td_name.text.strip() == name:
                    buttons = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td/a/i"))
                    return buttons[0], buttons[1], buttons[2]
        except (TimeoutException, ValueError):
            return None

    def get_rack_role_buttons_by_name(self, name):
        """Gets the button edit and delete from role's table."""
        self.rack_roles_page()
        self.go_filters()
        self.input_search_filters(name)
        self.search_button_filters()
        try:
            rows = self.get_elements(SSoT.rows_selector)
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table/tbody/tr[{row}]/td"))
                check, td_name, racks, _, _, buttons = list(columns)
                if td_name.text.strip() == name:
                    buttons = self.get_elements((By.XPATH, f"//table/tbody/tr[{row}]/td/a/i"))
                    return buttons[1], buttons[2]
        except (TimeoutException, ValueError):
            return None

    def get_platform_buttons_by_name(self, name):
        """Gets the button edit and delete from role's table."""
        self.platform_page()
        self.input_search_filters(name)
        self.search_button_filters()
        try:
            rows = self.get_elements(SSoT.rows_selector)
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, Name, _, _, _, _, _, _, buttons = list(columns)
                if Name.text.strip() == name:
                    buttons = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td/a/i"))
                    return buttons[0], buttons[1], buttons[2]
        except (TimeoutException, ValueError):
            return None

    def get_circuit_types_buttons_by_name(self, name):
        """Gets the button edit and delete from role's table."""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, td_name, circuit, description, buttons = list(columns)
                if td_name.text.strip() == name:
                    buttons = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td/a/i"))
                    return buttons[0], buttons[1], buttons[2]
        except (TimeoutException, ValueError):
            return None

    def search_field(self, field):
        """Search a device by text field."""
        self.get_element(SSoT.search_box_selector)
        self.set_text(SSoT.search_box_selector, field)

    def get_devices(self) -> list:
        """Returns a list of devices.
        Returns:
            Devices list (list): List of devices"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            devices = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, name, status, tenant, role, _, site, _, _ = [column.text.strip() for column in columns]
                devices.append(dict(NAME=name, STATUS=status, ROLE=role, SITE=site, TENANT=tenant))
            return devices
        except (TimeoutException, ValueError):
            return []

    def search_device(self, field: str, row="NAME") -> bool:
        """Returns if found a device by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.devices_page()
        self.input_search_filters(field)
        self.search_button_filters()
        elements = self.get_devices()
        return any([True if element[row] in field else False for element in elements])

    def search_location(self, field: str, row="NAME") -> bool:
        """Returns if found a site by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.locations_page()
        self.input_search_filters(field)
        self.search_button_filters()
        sites = self.get_location()
        return any([True if site[row] in field else False for site in sites])

    def get_location(self) -> list:
        """Returns a list of sites.
        Returns:
            Sites list (list): List of sites"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            location = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, name, status, _, _, _, _, _ = [column.text.strip() for column in columns]
                location.append(dict(NAME=name, STATUS=status))
            return location
        except (TimeoutException, ValueError):
            return []

    def get_pagination(self):
        locator = SSoT.pagination
        try:
            pages = self.get_elements(locator)
            page = len(pages)
            return page - 1
        except (TimeoutException, ValueError):
            value = 1
            return value

    def get_device_types(self) -> list:
        """Returns a list of device types.
        Returns:
            Device Types list (list): List of device types"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            device_types = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, device_type, manufacture, _, _, _, _ = [column.text.strip() for column in columns]
                device_types.append(dict(MODEL=device_type, MANUFACTURE=manufacture))
            return device_types
        except (TimeoutException, ValueError):
            return []

    def search_device_type(self, field: str, row="MODEL") -> bool:
        """Returns if found a device type by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.device_types_page()
        self.input_search_filters(field)
        self.search_button_filters()
        device_types = self.get_device_types()
        return any([True if device_type[row] in field else False for device_type in device_types])

    def search_circuit(self, field: str, row="ID") -> bool:
        """Returns if found a device type by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.circuits_page()
        self.input_search_filters(field)
        self.search_button_filters()
        circuits = self.get_circuit()
        return any([True if circuit[row] in field else False for circuit in circuits])

    def get_circuit(self) -> list:
        """Returns a list of device types.
        Returns:
            Device Types list (list): List of device types"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            circuits = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, id, provider, type, status, tenant, _, _,_ = [column.text.strip() for column in columns]
                circuits.append(dict(ID=id))
            return circuits
        except (TimeoutException, ValueError):
            return []

    def search_provider(self, field: str, row="NAME") -> bool:
        """Returns if found a device type by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.providers_page()
        self.input_search_filters(field)
        self.search_button_filters()
        providers = self.get_provider()
        return any([True if provider[row] in field else False for provider in providers])

    def get_provider(self) -> list:
        """Returns a list of device types.
        Returns:
            Device Types list (list): List of device types"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            providers = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, name, asn, account, circuits = [column.text.strip() for column in columns]
                providers.append(dict(NAME=name))
            return providers
        except (TimeoutException, ValueError):
            return []

    def search_circuit_types(self, field: str, row="NAME") -> bool:
        """Returns if found a device type by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.circuit_types_page()
        self.input_search_filters(field)
        self.search_button_filters()
        circuit_types = self.get_circuit_types()
        return any([True if circuit_type[row] in field else False for circuit_type in circuit_types])

    def get_circuit_types(self) -> list:
        """Returns a list of device types.
        Returns:
            Device Types list (list): List of device types"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            circuit_types = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, name, circuit, desc, _ = [column.text.strip() for column in columns]
                circuit_types.append(dict(NAME=name))
            return circuit_types
        except (TimeoutException, ValueError):
            return []

    def home_page(self, setup_server_url):
            url = setup_server_url
            self.go_url(url)
            self.get_element(SSoT.navbar)

    def get_title_module(self, name):
        locator = self.get_format_selector(SSoT.title_modules, name)
        self.get_element(locator, timeout=25)

    def get_values_table_details(self, rows_get):
        array = []
        for row in rows_get:
            locator = (By.XPATH, f"//td[contains(text(),'{row}')]/following-sibling::td")
            element = self.get_element(locator)
            value = element.get_attribute('innerText')
            print(row)
            if row == 'Height':
                value = value.replace("U", "")
            if row == 'Device Type':
                value = value.replace("(1U)", "")
            array.append(value.rstrip())
        return array

    def get_select_values_form_edit(self, rows_get):
        rows_value = []
        for row in rows_get:
            locator = (By.XPATH, f"//label[contains(text(),'{row}')]/../div/select/option[@selected]")
            element = self.get_element(locator)
            value = element.get_attribute('innerText')
            rows_value.append(value)
        return rows_value

    def get_input_values_form_edit(self, rows_get):
        rows_value = []
        for row in rows_get:
            locator = (By.XPATH, f"//label[contains(text(),'{row}')]/following-sibling::div/input")
            element = self.get_element(locator)
            value = element.get_attribute('defaultValue')
            rows_value.append(value)
        return rows_value

    def get_info_table_edit(self, simple_form=True, values=''):
        array = []
        headers_format = self.get_format_selector(SSoT.title_row_selector, "th")
        headers = self.get_elements(headers_format)
        headers = [header.text for header in headers]
        if simple_form:
            for value in values:
                position = headers.index(value)
                rows_format = self.get_format_selector(SSoT.title_row_selector, "tr.even:nth-child(1)>td")
                rows = self.get_elements(rows_format)
                array.append(rows[position].text)
        return array

    def get_values_form_edit(self, data, simple_form=True, index_item=" "):
        data = [row for row in data if "—" not in row]
        locator_inputs = (By.CSS_SELECTOR, "div.panel-body input")
        inputs = self.get_elements(locator_inputs)
        inputs = [input.get_attribute('value') for input in inputs]
        locator_selectors = (By.CSS_SELECTOR, "div.panel-body option")
        selectors = self.get_elements(locator_selectors)
        selectors = [selector.text for selector in selectors if "---------" not in selector.text]
        elements = selectors + inputs
        if simple_form:
            return all(element in elements for element in data)
        else:
            if index_item != " ":
                for i in index_item:
                    data.pop(i)
                return all(element in elements for element in data)

    def view_first_record_of_table(self):
        locator = (By.XPATH, '(//table/tbody/tr/td)[1]')
        self.click_on_element(locator)
        locator = locator = (By.XPATH, '(//table/tbody/tr/td/a)[1]')
        element = self.get_element(locator)
        text = element.text
        element.click()
        return text

    def switch_page(self, name):
        main_page = self.driver.current_window_handle
        for handle in self.driver.window_handles:
            if handle != main_page:
                print(handle)
                login_page = handle
                break
        self.driver.switch_to.window(login_page)
        assert self.is_title_present(name, type='span')
        self.driver.close()
        self.driver.switch_to.window(main_page)

    def click_plugin_install(self, text, type='h1'):
        locator = (By.XPATH, f"//{type}[contains(text(), '{text}')]")
        self.click_on_element(locator)

    def assert_version(self):
        version = (By.XPATH, "//td[text()='Version']/../td[2]")
        element = self.get_element(version)
        text = element.text
        return text

    def get_last_update(self):
        locator = (By.XPATH, '(//table/tbody/tr/td)[1]')
        self.click_on_element(locator)
        locator = (By.XPATH, '(//table/tbody/tr/td)[2]')
        element = self.get_element(locator)
        text = element.text
        return text

    def get_last_update_device(self):
        main_page = self.driver.current_window_handle
        for handle in self.driver.window_handles:
            if handle != main_page:
                print(handle)
                login_page = handle
                break
        self.driver.switch_to.window(login_page)
        locator = (By.XPATH, "//strong[contains(text(),'Indicators')]/../following-sibling::div/h3")
        element = self.get_element(locator)
        text = element.text
        return text
        self.driver.close()
        self.driver.switch_to.window(main_page)

    def view_change_log_of_first_record(self):
        element = self.get_element(SSoT.icon_change_log)
        self.click_on_element(element)

    def are_record_stats_present(self, modules):
        for module in modules:
            locator = (By.XPATH, f"//strong[contains(text(),'{module}')]")
            element = self.driver.find_elements(*locator)
            assert element, f'Stats for {module} module is not present'

    def get_index_of_table_columns(self):
        aux_columns = {'toggle_all': 1}
        locator = (By.XPATH, "//thead/tr/th/a")
        columns = self.get_elements(locator)
        [aux_columns.update({column.text.lower(): index + 2}) for index, column in enumerate(columns)]
        return aux_columns

    def get_snow(self) -> list:
        """Returns a list of devices.
        Returns:
            Devices list (list): List of devices"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            devices = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                box, created, update,  device, stage, type, ticket,  owner, decome, error = list(columns)
                devices.append(dict(DEVICE=device.text.strip(), STAGE=stage.text.strip(), ACTION=type.text.strip(),
                                    TICKET=ticket.text.strip(), BOX=box))
            return devices
        except (TimeoutException, ValueError):
            return []

    def select_checkbox(self, name, stag, row1="DEVICE", row3="STAGE", checkbox=False):
        rows = self.get_snow()
        iteration = 0
        for item in rows:
            if checkbox:
                if item[row1] == name and item[row3] == stag:
                    while iteration < 1:
                        iteration = iteration + 1
                        print(iteration)
                        buttons = (By.XPATH, f"(//td/input)[{iteration}]")
                        self.get_element(buttons)
                        self.click_on_element(buttons)
                        time.sleep(1)

    def add_image(self):
        self.title_img()
        locator = (By.XPATH, "//strong[contains(text(),'Images')]/../following-sibling::div/a")
        self.click_on_element(locator)

    def add_file(self):
        self.title_img()
        locator = (By.XPATH, "//strong[contains(text(),'File')]/../following-sibling::div/a")
        self.click_on_element(locator)

    def form_img(self, name, img):
        locator_name = (By.ID, 'id_name')
        self.set_text(locator_name, name)
        locator_img = (By.ID, 'id_image')
        self.set_text(locator_img, img)

    def button_delete_img(self):
        self.title_img()
        local = (By.XPATH, "//a[@data-original-title='Delete image'][1]")
        self.click_on_element(local)
        self.click_confirm_button()

    def button_update_img(self):
        self.title_img()
        local = (By.XPATH, "//a[@data-original-title='Edit image'][1]")
        self.click_on_element(local)

    def go_filters(self):
        locator = (By.ID, "id__filterbtn")
        self.click_on_element(locator)

    def input_search_filters(self, field):
        self.set_text((By.XPATH, "(//input[@name='q'])[2]"), field)

    def search_button_filters(self):
        locator = (By.XPATH, "(//button[@class='btn btn-primary']/i[@class='mdi mdi-magnify'])[2]")
        self.click_on_element(locator)

    def log_out(self):
        locator = (By.XPATH, "(//button[contains(@class, 'btn btn-outline-secondary dropdown-toggle w-100')])[2]")
        if self.check_presence_of_element(locator, 1):
            self.click_on_element(locator)
            self.click_on_element((By.XPATH, "(//a[contains(@href, '/logout/')]/i)[2]"))

    def upload_csv_file(self, img):
        locator = (By.ID, 'id_csv_file')
        self.set_text(locator, img)

    def submit_file(self):
        locator = (By.XPATH, "//form//button[@type='submit'][text()='Submit']")
        self.click_on_element(locator)

    def title_present(self, name):
        locator = (By.XPATH, f"//strong[text()='{name}']")
        return self.get_element(locator)

    def text_h5(self, name):
        locator = (By.XPATH, f"//strong[contains(text(),'Circuits')]")
        return self.get_element(locator)