from .page import Page
from .locators import Page_Login, LoginLocators, HomeLocators


class Login(Page):

    def log_in(self, username, password):
        self.click_on_element(Page_Login.admin_log)
        self.get_element(LoginLocators.USERNAME)
        self.set_text(LoginLocators.USERNAME, username)
        self.set_text(LoginLocators.PASSWD, password)
        self.click_on_element(LoginLocators.SUBMIT)
        self.get_elements(HomeLocators.logo)

    def get_url_env(self, username, password):
        ruta = self.get_url()
        html = self.driver.page_source
        title = self.driver.title
        try:
            element = self.get_element(Page_Login.admin_log)
        except:
            element=False
        assert element, f"not found element in url {ruta} " \
                        f"user: {username} and pass: {password} title page: {title},html:{html}"
