import time
from selenium.webdriver.common.by import By
from .ssot import SSOTPage, SSoT
from tests.pom.selectors.ssot import PartialDiscover as partial


class SsotPartialDiscovery(SSOTPage, SSoT):
    """contains the function"""

    def check_text_area(self):
        self.get_element(partial.text_area)
        self.click_on_element(partial.text_area)
        return True

    def set_data(self, data):
        self.check_text_area()
        self.set_text(partial.text_area, data['IP'])

    def button_send(self):
        self.click_on_element(partial.button_submit)

    def check_job(self):
        self.check_presence_of_element((By.ID, "tabs"), timeout=36)
        locator = (By.ID, "copy_title")
        job_result = self.get_element(locator)
        text = job_result.text
        assert text == 'Job Result: Run IP Fabric Partial Discovery'

