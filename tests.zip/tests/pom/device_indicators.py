import time
from seleniumpagefactory.Pagefactory import PageFactory
from .ssot import SSOTPage
from tests.pom.selectors.ssot import SSoT, SSOTIndicators as SSOTInd
from selenium.common import TimeoutException, NoSuchElementException
from selenium.webdriver.support.wait import WebDriverWait
import csv


class DeviceIndicators(SSOTPage, PageFactory):

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.highlight = True
        self.timeout = 30

    # Define locators dictionary where key name will became WebElement using PageFactory
    locators = {
        'devices_select': ('id', 'drivers-select'),
    }

    def device_indicator(self):
        selector = SSoT.device_indicator_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.apps_menu()
            self.click_on_element(selector)
        self.get_title_module("Device Indicator")

    def device_cmdb(self):
        selector = SSoT.cmdb_dashboard_menu_selector
        if self.get_element(selector).is_displayed():
            self.click_on_element(selector)
        else:
            self.apps_menu()
            self.click_on_element(selector)
        self.get_title_module("Device Indicator")

    def get_total_filter_count(self):
        """Returns the total number of available filters in the dropdown."""
        dropdown = self.get_elements(SSOTInd.filter_dropdown)
        return len(dropdown)

    def select_device_filter(self, dropdown_index, location_index):
        """Selects a device location filter."""
        location_locator = self.get_locator(SSOTInd.rankgroup_dropdown, dropdown_index, location_index)
        location_dropdown = self.get_element(location_locator)
        return self.apply_filter(location_dropdown)

    def get_selected_filter_value(self, location_index):
        """Retrieves the value of the selected filter."""
        location_locator = self.get_locator(SSOTInd.filter_location_value, location_index)
        filter_element = self.get_element(location_locator)
        return filter_element.get_attribute('data-field-value')

    def get_locator(base_locator, *indices):
        """Formats a locator with multiple index values."""
        if isinstance(base_locator, tuple):
            locator_type, locator_string = base_locator  # Extract tuple values
            return locator_type, locator_string.format(*indices)  # Format with multiple indices
        return base_locator.format(*indices)

    def apply_filter(self, element):
        """Applies a selected filter, ensuring it is not an input field."""
        if not element.is_displayed():
            return False
        self.click_on_element(element)
        time.sleep(5)
        dropdown = self.get_elements(SSOTInd.location_dropdown_list, timeout=50)
        if dropdown[0].text == "No results found":
            self.click_on_element(element)
            return False
        location_option = self.get_element(SSOTInd.status_list)
        if location_option:
            self.click_on_element(location_option)
            return True
        return False

    def get_applied_filter_count(self):
        """Returns the count of applied filters."""
        dropdown = self.get_elements(SSOTInd.filter_locations)
        return len(dropdown) if dropdown else 0  # Return 0 if no filters found

    def click_apply_filter_button(self):
        """Clicks the apply filter button."""
        apply_button_locator = SSOTInd.apply_button
        self.get_element(apply_button_locator).is_displayed()
        self.driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight", apply_button_locator)
        self.click_on_element(apply_button_locator)

    def get_filtered_results_count(self):
        """Returns the count of filter results displayed."""
        filter_results = self.get_elements(SSOTInd.filter_result)
        return len(filter_results)

    def is_filter_result_empty(self):
        """Checks if the applied filter returns an empty result."""
        filter_result_element = self.get_element(SSOTInd.filter_result_nom)
        return 'No primary models found' in filter_result_element.text

    def get_current_url(self):
        """Fetches the current URL after applying filters."""
        return self.driver.current_url

    def click_clear_filters(self):
        """Clicks the clear filter button to reset filters."""
        clear_filter_button = SSOTInd.filter_closed
        self.get_element(clear_filter_button).is_displayed()
        self.click_on_element(clear_filter_button)

    def click_on_location_dropdown(self):
        """click  the  location filter  dropdown displayed."""
        filter_dropdowns = self.get_elements(SSOTInd.filter_dropdown)
        if not filter_dropdowns[0].is_displayed():
            return False
        location_dropdown = self.get_element(SSOTInd.filter_location_dropdown)
        if location_dropdown.is_displayed():
            self.click_on_element(location_dropdown)

    def click_on_status_dropdown(self):
        """click  the  status filter  dropdown displayed."""
        status_dropdown = self.get_element(SSOTInd.filter_status_dropdown)
        if status_dropdown.is_displayed():
            self.click_on_element(status_dropdown)

    def click_on_role_dropdown(self):
        """click  the  role filter  dropdown displayed."""
        role_dropdown = self.get_element(SSOTInd.filter_role_dropdown)
        if role_dropdown.is_displayed():
            self.click_on_element(role_dropdown)

    def click_on_servicenow_assignment_group_dropdown(self):
        """click  the   servicenow_assignment_group filter  dropdown displayed."""
        service_dropdown = self.get_element(SSOTInd.filter_service_dropdown)
        if service_dropdown.is_displayed():
            self.click_on_element(service_dropdown)

    def select_multi_filters(self, location_value, status_value, role_value, service_value)
        self.click_on_location_dropdown()
        self.select_location_filter_value(location_value)
        self.click_on_status_dropdown()
        self.select_status_filter_value(status_value)
        self.click_on_role_dropdown()
        self.select_role_filter_value(role_value)
        self.click_on_servicenow_assignment_group_dropdown()
        self.select_service_filter_value(service_value)

    def select_location_filter_value(self, filter_value):
        """select  the  location filter of value displayed."""
        self.set_text(SSOTInd.filter_location_input, filter_value)
        location_locator = self.get_locator(SSOTInd.filter_value, filter_value)
        self.click_on_element(location_locator)

    def select_status_filter_value(self, filter_value):
        """select  the  status filter of value displayed."""
        self.set_text(SSOTInd.filter_status_input, filter_value)
        status_locator = self.get_locator(SSOTInd.filter_value, filter_value)
        self.click_on_element(status_locator)

    def select_role_filter_value(self, filter_value):
        """select  the  role  filter of value displayed."""
        self.set_text(SSOTInd.filter_role_input, filter_value)
        role_locator = self.get_locator(SSOTInd.filter_value, filter_value)
        role_value = self.get_element(role_locator)
        self.click_on_element(role_value)

    def select_service_filter_value(self, filter_value):
        """select  the  service filter of value displayed."""
        service_list = self.get_locator(SSOTInd.filter_value, filter_value)
        service_value = self.get_element(service_list)
        self.click_on_element(service_value)

    def clear_all_filters(self):
        """Clicks the clear filter button to reset filters."""
        while self.get_elements(SSOTInd.remove_filter):
            clear_filters = self.get_elements(SSOTInd.remove_filter)
            if not clear_filters:
                break
            try:
                self.click_on_element(clear_filters[0])
                WebDriverWait(self.driver, 0.20).until(
                    lambda d: clear_filters[0] not in self.get_elements(SSOTInd.remove_filter)
                )
            except TimeoutException:
                break

    def get_filtered_results_text(self):
        """Returns the text of filter results displayed."""
        filter_results = self.get_elements(SSOTInd.filter_result)
        return filter_results[0].text if filter_results else False

    @staticmethod
    def get_filter_values_from_csv(file_path, column_name, row_index):

        """Reading nme from csv file"""
        with open(file_path, mode='r', newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            rows = list(reader)
            if row_index < len(rows):
                return rows[row_index][column_name]
            else:
                raise IndexError(f"Row index{row_index} is out of range")

    def get_device_icmp_enabled_status(self):
        """ Return the devices status text from row"""
        try:
            icmp_element = self.get_element(SSOTInd.icmp_enabled)
            is_element_displayed = icmp_element.is_displayed()
            if is_element_displayed:
                return icmp_element.text

    def get_device_icmp_working_status(self):
        """ Return the devices status text from row"""
        try:
            icmp_element = self.get_element(SSOTInd.icmp_working)
            is_element_displayed = icmp_element.is_displayed()
            if is_element_displayed:
                return icmp_element.text
            return None
        except NoSuchElementException:
            return None

    def get_device_snmp_enabled_status(self):
        """ Return the devices status text from row"""
        try:
            icmp_element = self.get_element(SSOTInd.snmp_enabled)
            is_element_displayed = icmp_element.is_displayed()
            if is_element_displayed:
                return icmp_element.text
            return None
        except NoSuchElementException:
            return None

    def get_device_snmp_working_status(self):
        """ Return the devices status text from row"""
        try:
            icmp_element = self.get_element(SSOTInd.snmp_working)
            is_element_displayed = icmp_element.is_displayed()
            if is_element_displayed:
                return icmp_element.text
            return None
        except NoSuchElementException:
            return None

    def click_on_device(self):
        """Click the  device"""
        devices = self.get_element(SSOTInd.filter_result)
        self.click_on_element(devices)

    @staticmethod
    def is_field_valid_status(value, expected):
        return value in expected
