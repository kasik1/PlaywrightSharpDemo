from .ssot import SSOTPage
from selenium.webdriver.common.by import By
from tests.pom.selectors.ssot import SSoTTenantGroup as SSoTTG


class SSOTTenantGroup(SSOTPage):
    """contains the functions to run the tenants group module"""

    def add_tenant_group(self, data):
        """Add a Tenant Group."""
        self.tenant_group_page()
        self.click_add_button()
        self.set_tenant_group_data(data)
        self.click_submit_button()

    def set_tenant_group_data(self, data):
        """Sets the data for the Tenant Group inputs."""
        self.get_element(SSoTTG.name_selector)
        self.set_text(SSoTTG.name_selector, data['FIRST_NAME'])
        self.set_text(SSoTTG.description_selector, data['DESCRIPTION'])
        if data['PARENT'] != '':
            self.set_select_data(SSoTTG.parent_selector, data["PARENT"])

    def edit_tenant_groups(self, data):
        """Edit a Tenant Group."""
        self.tenant_group_page()
        # self.go_filters()
        self.input_search_filters(data['FIRST_NAME'])
        self.search_button_filters()
        self.click_on_element(SSoTTG.edit_tenant_group)
        self.set_tenant_group_data(data)
        self.click_update_button()

    def delete_tenant_groups(self, data):
        """Delete a Tenant Group."""
        self.tenant_group_page()
        # self.go_filters()
        self.input_search_filters(data['FIRST_NAME'])
        self.search_button_filters()
        self.click_on_element(SSoTTG.delete_tenant_group)
        self.click_confirm_button()

    def delete_specific_tenant_groups(self, groups=[]):
        """Delete a Tenant Group."""
        for group in groups:
            self.tenant_group_page()
            locator = (By.XPATH, f"//td/a[contains(text(), '{group}')]/../..//i[@class='mdi mdi-trash-can-outline']")
            element = self.get_element(locator)
            element.click()
            self.click_confirm_button()

    def view_first_tenants_group(self):
        locator = (By.XPATH, '//tbody/tr[1]/td[2]/a[2]')
        self.click_on_element(locator)
