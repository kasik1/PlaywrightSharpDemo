from selenium.webdriver.common.by import By
from .ssot import SSOTPage
from tests.pom.selectors.ssot import SSoT


class SSOTGeneralSearchTool(SSOTPage):
    """"The general search tool is the class with the methods for testing SSOT main search tool."""

    def set_search_nav(self, data):
        """perform the action of selecting the search box and insert the text that comes from the test data
        param data: is the value you are going to look for e.g. Cigna"""
        locator = SSoT.search_nav
        self.set_text(locator, data)
        self.click_on_element(
            (By.XPATH, "((//input[@name='q'])[1])/../span/button"))

    def get_objects(self):
        locator = (By.XPATH, "//div[@class='list-group']")
        rows = self.get_elements(locator)
        for row in rows:
            text = row.text
            print(text)
        split_text = text.split("\n")
        value_numeric_object = split_text[1::2]
        value_object = split_text[0::2]
        return value_object, value_numeric_object

    def select_object(self, option, data_search,count_row=False):
        """This method performs the action of selecting in the search. It specifies the object that is the module
        on which it is going to search for the value that was inserted in the search engine.
        parameter data: is the list of modules on which the search will run e.g. ['Site','Device','Tenant','Contacts']
        parameter count_row: this parameter in true will activate the function of counting the elements that appear in
        the table of the modules and comparing against the results that the search engine shows of the elements found"""
        locator = SSoT.search_nav
        self.set_text(locator, data_search)
        self.click_on_element((By.ID, "id_obj_type"))
        if option == "Virtual Chassis":
            self.click_on_element((By.XPATH, "//option[contains(text(), 'virtual chassis')]"))
        elif option == "IP Addresses":
            self.click_on_element((By.XPATH, "//option[contains(text(), 'IP addresses')]"))
        elif option == "VLANs":
            self.click_on_element((By.XPATH, "//option[contains(text(), 'VLANs')]"))
        elif option == "VRFs":
            self.click_on_element((By.XPATH, "//option[contains(text(), 'VRFs')]"))
        else:
            self.click_on_element((By.XPATH, f"//option[contains(text(),'{option.lower()}')]"))
        self.click_on_element(
            (By.XPATH, "//button[contains(text(), 'Search')]"))
        if count_row:
            self.click_button_all_results()
            rows = self.count_rows_search()
            self.click_button_50_results()
        else:
            rows = 0
        return True, option, rows

    def click_button_all_results(self):
        self.click_on_element((By.XPATH, "//a[@class='btn btn-primary pull-right']"))
        self.click_on_element((By.NAME, "per_page"))
        self.get_element((By.XPATH, "//option[text()='1000']"))
        self.click_on_element((By.XPATH, "//option[text()='1000']"))

    def click_button_50_results(self):
        self.click_on_element((By.NAME, "per_page"))
        self.get_element((By.XPATH, "//option[text()='50']"))
        self.click_on_element((By.XPATH, "//option[text()='50']"))

    def count_rows_search(self):
        locator = (By.XPATH, "//table[@class='table table-hover table-headings']/tbody/tr")
        rows = self.get_elements(locator)
        result = len(rows)
        self.back_page()
        return str(result)

    def line_search(self, name):
        title = name.lower()
        locator = (By.XPATH, f"//div[@class='list-group']/a[@href='#{title}']/span")
        number = self.get_element(locator)
        return number.text