from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from .ssot import SSOTPage, SSoT


class SSOTDeviceBulk(SSOTPage, SSoT):
    """contains the function"""

    def check_csv_data(self):
        locator = (By.XPATH, "//*[@id='main-content']/div[2]/div/ul/li[1]/a")
        self.get_element(locator)
        self.click_on_element(locator)
        return True

    def check_csv_file(self):
        locator = (By.XPATH, "//*[@id='main-content']/div[2]/div/ul/li[2]/a")
        self.get_element(locator)
        self.click_on_element(locator)
        return True

    def insert_data_text(self, data):
        locator = (By.ID, "id_csv_data")
        self.get_element(locator)
        self.set_text(locator, data)

    def click_submit_button(self):
        locator = (By.XPATH, "//*[@id='csv-text']/form/div[2]/div/button")
        self.get_element(locator)
        self.click_on_element(locator)

    def delete_device(self, name):
        """Delete a device."""
        self.click_link_text(name)
        self.click_delete_button()
        self.click_confirm_button()

    def add_csv_file(self, file):
        locator = (By.ID, "id_csv_file")
        self.set_text(locator, file)

    def submit_csv(self):
        locator = (By.XPATH, "//*[@id='csv-file']/form/div[2]/div/button")
        self.get_element(locator)
        self.click_on_element(locator)

    def get_device_unclaimed_date(self):
        """Get device unclaimed date"""
        device_status = (By.XPATH, " //span[text()='Unclaimed Date']/following::td[1]")
        element = self.get_element(device_status)
        return element.text if element else False

    def get_device_status(self):
        """ Return the devices status text from row"""
        device_status = (By.XPATH, "//td[text()='Status']/following-sibling::td/span/a")
        element = self.get_element(device_status)
        return element.text if element else False

    def delete_unclaimed_device(self, name):
        """Delete unclaimed a device."""
        self.click_on_element(SSoT.delete_dropdown_device)
        self.click_on_element(SSoT.delete_button_link)
        self.click_confirm_button()
