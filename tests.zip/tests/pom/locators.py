from selenium.webdriver.common.by import By


class Page_Login:
    admin_log = (By.XPATH, "//strong[contains(text(),'Log In')]")


class LoginLocators:
    USERNAME = (By.NAME, 'username')
    PASSWD = (By.NAME, 'password')
    SUBMIT = (By.XPATH, "//button[contains(text(),'Log In')]")


class HomeLocators:
    logo = (By.ID, "navbar_search")
