from selenium.webdriver.common.by import By
from .ssot import SSOTPage
from datetime import datetime
from tests.pom.selectors.ssot import SSoTInventorySelectors, SSoT


class SSOTInventory(SSOTPage):
    """Contains the functions to run the inventory module"""


    def select_item_checkbox(self):
        """Select a item in the checkbox."""
        selector = SSoTInventorySelectors.items_first_check_box
        self.click_on_element(selector)

    def select_checkbox_search(self):
        """Select a item in the checkbox."""
        selector = SSoTInventorySelectors.checkbox_search
        self.click_on_element(selector)

    def view_first_inventory(self):
        locator = (By.XPATH, '//tbody/tr[1]/td[3]/a[1]')
        self.click_on_element(locator)

    def is_inventory_description_present(self):
        module = ["Inventory Item", "Relationships", "Tags"]
        for item in module:
            locator = (By.XPATH, f"//strong[contains(text(),'{item}')]")
            element = self.driver.find_elements(*locator)
            assert element, f'inventory stats for {item} module is not present'

    def is_tab_inventory_present(self):
        title = self.get_format_selector(selector=SSoT.link_selector, item="Inventory Items")
        return self.get_element(title)

    def edit_item_selected(self):
        """Edit a item selected."""
        self.click_on_element(SSoTInventorySelectors.edit_selected_button)

    def delete_item_selected(self):
        """Delete a item."""
        self.click_on_element(SSoTInventorySelectors.action_button)
        self.click_on_element(SSoTInventorySelectors.delete_option)

    def click_apply_button(self):
        """Clicks submit button"""
        self.click_on_element(SSoTInventorySelectors.apply_button_selector)

    def get_asset_from_table(self):
        index = False
        ssot_inventory = SSoTInventorySelectors()
        elements = self.get_elements(ssot_inventory.table_headers)
        for index, element in enumerate(elements):
            if element.text == 'Asset tag':
                index = index + 1
                break
        ssot_inventory.set_value(index)
        element = self.get_element(ssot_inventory.table_header_asset_tag)
        return element.text

    def fill_edit_inventory_item_form(self, data):
        ssot_inventory = SSoTInventorySelectors()
        form_inputs = ['label',
                       'part_id',
                       'description']
        for key in form_inputs:
            if key == 'label':
                input_value = data['label_pattern']
            else:
                input_value = data[key]
            ssot_inventory.set_value(key)
            selector = ssot_inventory.inventory_form_input
            self.set_text(selector, input_value)

    def fill_inventory_item_form(self, data):
        ssot_inventory = SSoTInventorySelectors()
        asset_tag = ''

        # Input
        form_inputs = ['name_pattern',
                       'label_pattern',
                       'part_id',
                       'serial',
                       'asset_tag',
                       'description']
        for key in form_inputs:
            input_value = data[key]
            ssot_inventory.set_value(key)
            selector = ssot_inventory.inventory_form_input
            if key == 'asset_tag':
                input_value = str(datetime.time(datetime.today())).split('.')[0]
                asset_tag = input_value
            self.set_text(selector, input_value)

        # Checkbox
        if data['discovered'] == 'TRUE':
            ssot_inventory.set_value('discovered')
            selector = ssot_inventory.inventory_form_input
            self.click_on_element(selector)

        # Select
        self.click_on_element(SSoTInventorySelectors.manufacturer_select)
        self.click_on_element(SSoTInventorySelectors.manufacturer_select_option_1)
        return asset_tag

    def check_inventory_item_assert_tag(self, asset_tag):
        ssot_inventory = SSoTInventorySelectors()
        ssot_inventory.set_value(asset_tag)
        selector = ssot_inventory.asset_tag
        return self.get_element(selector)

    def check_update(self):
        result_status = (By.XPATH, "//span[@id='pending-result-label']/label[contains(text(),'Completed')]")
        status = self.get_element(result_status, timeout=60).text
        if status == "Completed":
            element = self.get_element(SSoTInventorySelectors.return_value)
            value = element.get_attribute('innerText')
            value = value.replace('"', '')
            return value
        else:
            self.get_element(result_status, timeout=60).text
            return self.check_update()

    def check_delete(self):
        result_status = (By.XPATH, "//span[@id='pending-result-label']/label[contains(text(),'Completed')]")
        status = self.get_element(result_status, timeout=60).text
        if status == "Completed":
            return True
        else:
            self.get_element(result_status, timeout=60).text
            return self.check_update()