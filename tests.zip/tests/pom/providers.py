from selenium.webdriver.common.by import By
from .ssot import SSOTPage
from tests.pom.selectors.ssot import SSoTProviders as SSoTProv


class SSoTProviders(SSOTPage):
    """contains the functions to run the tenants module"""

    def add_providers(self, data):
        """Add a Provider."""
        self.providers_page()
        self.click_add_button()
        self.set_provider_data(data)
        self.click_submit_button()

    def set_provider_data(self, data):
        """Sets the data for the Provider inputs."""
        self.get_element(SSoTProv.name_provider)
        self.set_text(SSoTProv.name_provider, data['PROVIDER'])
        self.set_text(SSoTProv.asn_provider, data['ASN'])
        self.set_text(SSoTProv.account_number, data['ACCOUNT'])
        self.set_text(SSoTProv.comment_provider, data['COMMENTS'])

    def are_provider_stats_present(self):
        modules = ['Provider', 'Tags', 'Comments', 'Circuits']
        for module in modules:
            locator = (By.XPATH, f"//strong[contains(text(),'{module}')]")
            element = self.driver.find_elements(*locator)
            assert element, f'Circuit stats for {module} module is not present'

    def edit_provider(self, provider, data):
        """Edit a Provider."""
        self.click_link_text(provider)
        self.click_edit_button()
        self.set_provider_data(data)
        self.click_update_button()

    def delete_provider(self, provider):
        """Delete a Circuit."""
        self.click_link_text(provider)
        self.click_delete_button()
        self.click_confirm_button()
