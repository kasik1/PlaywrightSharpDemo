import time

from selenium.common.exceptions import TimeoutException
from .ssot import SSOTPage
from selenium.webdriver.common.by import By
from tests.pom.selectors.ssot import SSoT


class JOB_Results(SSOTPage):
    """"SSOTLocations is the class with the methods for module locations."""

    def table_titles(self):
        titles = []
        try:
            rows = self.get_elements(SSoT.rows_selector)
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/thead/tr/th"))
                check, td_name, _, _, _, _, _, _ = list(columns)
                return titles
        except (TimeoutException, ValueError):
            return None

    def view_first_job(self):
        locator = (By.XPATH, '//table[@class="table table-hover table-headings"]/tbody/tr[1]/td[2]/a[1]')
        self.click_on_element(locator)

    def verify_card_sumary(self):
        names = ['Status', 'Started at', 'User', 'Duration', 'Return Value']
        for row in names:
            locator = (By.XPATH, f"//td[contains(text(),'{row}')]/following-sibling::td")
            self.get_element(locator)
        return True

    def click_on_job_model(self, job_model):
        locator = (By.XPATH, f"(//td[contains(text(),'{job_model}')])[1]/../td[2]")
        self.click_on_element(locator)

    def check_message(self, message):
        locator = (By.XPATH, f"//td/p[contains(text(),'{message}')]")
        self.check_presence_of_element(locator, timeout=30)

    def check_level(self, message, level):
        locator = (By.XPATH, f"//td/p[contains(text(),'{message}')]/../../td/label[contains(text(),'{level}')]")
        check_item = self.check_presence_of_element(locator, timeout=30)
        return check_item

    def view_file_output(self):
        locator = (By.XPATH, "(//td[contains(text(),'File Output(s)')])/../td/ul/li")
        text = self.get_element(locator).text
        if text != "" or text != " ":
            return True

    def get_jobs(self) -> list:
        """Returns a list of devices.
        Returns:
            Devices list (list): List of devices"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            jobs = []
            for row in range(1, len(rows) + 1):
                columns = self.get_elements(
                    (By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, _, name, _, _, _, _, _ = [column.text.strip() for column in columns]
                jobs.append(dict(NAME=name))
            return jobs
        except (TimeoutException, ValueError):
            return []

    def search_device(self, field: str, row="NAME") -> bool:
        """Returns if found a device by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.job_results_page()
        self.input_search_filters(field)
        self.search_button_filters()
        elements = self.get_jobs()
        return any([True if element[row] in field else False for element in elements])

    def click_missing_job(self):
        locator = (By.XPATH, "//a[text()='ReportMissingDevicesJob']")
        self.click_on_element(locator)

    def click_update_job(self):
        locator = (By.XPATH, "//a[text()='CI Needs Update Report']")
        self.click_on_element(locator)

    def click_duplicate_job(self):
        locator = (By.XPATH, "//a[text()='CMDB Duplicate CI Report']")
        self.click_on_element(locator)

    def get_duplicate_job_text(self):
        locator = (By.XPATH, "//a[text()='CMDB Duplicate CI Report']")
        duplicate_job_element = self.get_element(locator)
        return duplicate_job_element.text if duplicate_job_element else False

    def get_update_job_text(self):
        locator = (By.XPATH, "//a[text()='CI Needs Update Report']")
        updated_job_element = self.get_element(locator)
        return updated_job_element.text if updated_job_element else False

    def get_missing_job_text(self):
        locator = (By.XPATH, "//a[text()='ReportMissingDevicesJob']")
        missing_job_element = self.get_element(locator)
        return missing_job_element.text if missing_job_element else False

    def click_on_run_job(self):
        locator = (By.ID, "id__run")
        self.click_on_element(locator)

    def get_job_status(self, status):
        is_loaded = self.text_in_element(SSoT.device_status, status, timeout=80)
        if is_loaded:
            element = self.is_element_clickable(SSoT.device_status, timeout=10)
            return element.text if element else False

    def click_test_user(self):
        self.click_on_element(SSoT.user_link)

    def click_device_email_address(self):
        self.click_on_element(SSoT.missing_device_email_address_link)

    def click_update_device_email_address(self):
        self.click_on_element(SSoT.update_device_email_address_link)

    def click_duplicate_device_email_address(self):
        self.click_on_element(SSoT.duplicated_device_email_address_link)

    def click_admin_button(self):
        self.click_on_element(SSoT.admin_link)

    def capture_current_email(self):
        self.click_on_element(SSoT.email_address_link)
        element = self.is_element_clickable(SSoT.email_address)
        return element.text if element else False

    def clear_email_address(self):
        email_input = self.get_element(SSoT.email_address)
        self.set_text(SSoT.email_address, '')
        email_input.send_keys('" "')
        self.click_on_element(SSoT.save_button)

    def get_update_job_name(self):
        job_element = self.get_element(SSoT.update_device_email_address_link)
        return job_element.text if job_element else False

    def get_duplicated_job_name(self):
        job_element = self.get_element(SSoT.duplicated_device_email_address_link)
        return job_element.text if job_element else False

    def get_missing_job_name(self):
        job_element = self.get_element(SSoT.missing_device_email_address_link)
        return job_element.text if job_element else False

    def navigate_to_device_email_page(self, job_name):
        self.click_test_user()
        self.click_admin_button()
        actions = {
            self.get_update_job_name(): self.click_update_device_email_address,
            self.get_duplicated_job_name(): self.click_duplicate_device_email_address,
            self.get_missing_job_name(): self.click_device_email_address,
        }
        action = actions.get(job_name, self.click_device_email_address)  # Default fallback
        action()

    def search_and_run_job(self, job_name):
        self.job_page()
        self.input_search_filters(job_name)
        actions = {
            self.get_update_job_text(): self.click_update_job,
            self.get_duplicate_job_text(): self.click_duplicate_job,
            self.get_missing_job_text(): self.click_missing_job,
        }
        self.search_button_filters()
        action = actions.get(job_name, self.click_device_email_address)  # Default fallback
        action()
        self.click_on_run_job()

    def add_and_clear_email(self):
        self.click_on_element(SSoT.add_email_button)
        self.clear_email_address()

    def delete_and_confirmation_button(self):
        self.click_on_element(SSoT.email_address_link)
        self.click_on_element(SSoT.delete_email_link)
        self.click_on_element(SSoT.yes_button)

    def get_delete_devices_alert_text(self):
        element = self.is_element_clickable(SSoT.alert_success_selector)
        return element.text if element else False
