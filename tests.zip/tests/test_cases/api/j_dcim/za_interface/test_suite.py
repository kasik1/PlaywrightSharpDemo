import pytest


@pytest.mark.smoke
class TestInterfaceSmokeTesting:

    def setup(self):
        self.url_interface = '/api/dcim/interfaces/'

    @pytest.mark.parametrize('test_data', ['test_get_interface'], indirect=True)
    def test_get_interface(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['results']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(end_point)
            module.set_headers(header)
            response = module.get()
            response_results(response)
            response_asserts(response)
            response_assert_fields(response, response_fields)

    @pytest.mark.parametrize('test_data', ['test_get_interface_trace'], indirect=True)
    def test_get_interface_trace(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey,
                              get_object_id, get_random_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_interface)
            module.set_headers(header)
            response = module.get()
            if response.json()['results']:
                get_id_interface = get_object_id(module)
                module = http(end_point)
                module.set_headers(header)
                response = module.get(get_id_interface)
                response_results(response, print_json_rows=False)
                response_asserts(response)


@pytest.mark.parallel
@pytest.mark.functional
class TestInterface:

    def setup(self):
        self.url_interface = '/api/dcim/interfaces/'
        self.url_devices = '/api/dcim/devices'

    @staticmethod
    def create_entry_for_testing(http, row, end_point, get_id_device, apikey, status_id, return_id=True):
        """ This method creates the payload to be sent in the rquest of the following test cases,
        Payload : is the set of data that will be sent to generate the intake ticket
        Module : contains the instruction for the execution of the method to be carried out, example: post (), get () etc.
        Response : contains the response after the post was executed, or get
        Create an if : this looks for the id tag in the respons to check that the pyload was generated correctly"""
        module = http(end_point)
        header = {"Authorization": f'{apikey}',
                  'Content-type': 'application/json'}
        payload = {
            "device": get_id_device,
            "name": row['name'],
            "label": row['label'],
            "type": row['type'],
            "status": status_id,
            "description": row['desc']
        }
        module.set_headers(header)
        module.set_body(payload)
        response = module.post()
        if return_id:
            assert 'id' in response.json(), "New Automation Request entry for testing was not created successfully."
            return response.json()['id']

    def get_status_id(self, http, header):
        module = http('/api/extras/statuses/')
        module.set_headers(header)
        response = module.get(name='Active')
        results = response.json()['results']
        return results[0]['id']

    @pytest.mark.parametrize('test_data', ['test_get_interface_id'], indirect=True)
    def test_get_interface_id(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey,
                              get_object_id, get_random_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['id', 'url', 'display']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_interface)
            module.set_headers(header)
            response = module.get()
            if not response.json()['results']:
                module_2 = http(self.url_devices)
                module_2.set_headers(header)
                get_id_device = get_object_id(module_2)
                status_id = self.get_status_id(http, header)
                self.create_entry_for_testing(http, row, '/api/dcim/interfaces/', get_id_device, apikey, status_id)
            get_id_interface = get_object_id(module)
            module = http(end_point)
            module.set_headers(header)
            response = module.get(get_id_interface)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, response_fields)

    @pytest.mark.parametrize('test_data', ['test_post_create_interface'], indirect=True)
    def test_post_create_interface(self, http, test_data, response_results, apikey, response_asserts,
                                   response_assert_fields, get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {"Authorization": f'{apikey}',
                      'Content-type': 'application/json'}
            module = http(self.url_devices)
            module.set_headers(header)
            status_id = self.get_status_id(http, header)
            get_id_device = get_object_id(module)
            payload = {
                "device": get_id_device,
                "name": row['name'],
                "label": row['label'],
                "type": row['type'],
                "status": status_id,
                "description": row['desc']
            }
            module = http(end_point)
            module.set_body(payload)
            module.set_headers(header)
            response = module.post()
            response_results(response, print_json_rows=False)
            response_asserts(response, status_code=201)
            response_assert_fields(response, payload)
            object_id = response.json()['id']
            get_end_point = '/api/dcim/interfaces/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

    @pytest.mark.parametrize('test_data', ['test_put_update_interface'], indirect=True)
    def test_put_update_interface(self, http, test_data, response_results, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_interface)
            module.set_headers(header)
            get_id_interface = get_object_id(module)
            get_id_devices = get_object_data(module, "device")['id']
            get_name = get_object_data(module, "name")
            get_label = get_object_data(module, "label")
            get_type = get_object_data(module, "type")['value']
            status_id = self.get_status_id(http, header)
            payload = [{
                "id": get_id_interface,
                "device": get_id_devices,
                "name": get_name,
                "label": get_label,
                "type": get_type,
                "status": status_id,
                "description": row['desc']
            }]
            module = http(end_point)
            module.set_headers(header)
            module.set_body(payload)
            response = module.put()
            response_results(response, print_json_rows=False)
            assert response.json()[0]['id'] == get_id_interface, f"The Json so_that is not equal to {get_id_interface}."
            assert response.json()[0]['name'] == get_name, f"The Json accep.is not equal{get_name}."

    @pytest.mark.parametrize('test_data', ['test_put_update_interface_id'], indirect=True)
    def test_put_update_interface_id(self, http, test_data, response_results, response_asserts,
                                     response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_interface)
            module.set_headers(header)
            get_id_interface = get_object_id(module)
            get_id_devices = get_object_data(module, "device")['id']
            get_name = get_object_data(module, "name")
            get_label = get_object_data(module, "label")
            get_type = get_object_data(module, "type")['value']
            status_id = self.get_status_id(http, header)
            module = http(end_point)
            payload = {
                "device": get_id_devices,
                "name": get_name,
                "label": get_label,
                "type": get_type,
                "status": status_id,
                "description": row['desc']
            }
            module.set_headers(header)
            module.set_body(payload)
            response = module.put(get_id_interface)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, payload)
            assert response.json()['id'] == get_id_interface, f"The Json accep.is not equal{get_id_interface}."
            assert response.json()['name'] == get_name, f"The Json accep.is not equal{get_name}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_interface'], indirect=True)
    def test_patch_update_interface(self, http, test_data, response_results, get_object_id, get_object_data, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_interface)
            module.set_headers(header)
            get_id_interface = get_object_id(module)
            get_id_devices = get_object_data(module, "device")['id']
            get_name = get_object_data(module, "name")
            get_label = get_object_data(module, "label")
            get_type = get_object_data(module, "type")['value']
            module = http(end_point)
            payload = [{
                "id": get_id_interface,
                "device": get_id_devices,
                "name": get_name,
                "label": get_label,
                "type": get_type,
                "description": row['desc']
            }]
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch()
            response_results(response, print_json_rows=False)
            assert response.json()[0]['id'] == get_id_interface, f"The Json so_that is not equal to {get_id_interface}."
            assert response.json()[0]['name'] == get_name, f"The Json accep.is not equal{get_name}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_interface_id'], indirect=True)
    def test_patch_update_interface_id(self, http, test_data, response_results, response_asserts,
                                       response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_interface)
            module.set_headers(header)
            get_id_interface = get_object_id(module)
            get_id_devices = get_object_data(module, "device")['id']
            get_name = get_object_data(module, "name")
            get_label = get_object_data(module, "label")
            get_type = get_object_data(module, "type")['value']
            module = http(end_point)
            payload = {
                "device": get_id_devices,
                "name": get_name,
                "label": get_label,
                "type": get_type,
                "description": row['desc']
            }
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch(get_id_interface)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, payload)
            assert response.json()['id'] == get_id_interface, f"The Json accep.is not equal{get_id_interface}."
            assert response.json()['name'] == get_name, f"The Json accep.is not equal{get_name}."

    @pytest.mark.parametrize('test_data', ['test_delete_interface'], indirect=True)
    def test_delete_interface(self, http, test_data, response_results, response_asserts,
                              response_assert_fields, apikey, get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            header = {"Authorization": f'{apikey}'}
            module = http(self.url_devices)
            module.set_headers(header)
            get_id_devices = get_object_id(module)
            status_id = self.get_status_id(http, header)
            object_id = self.create_entry_for_testing(http, row, '/api/dcim/interfaces/', get_id_devices, apikey, status_id)
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

            get_end_point = '/api/dcim/interfaces/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.get(object_id)
            assert response.status_code == 404, "The status code not is equal at 404"
