import pytest


@pytest.mark.data_load
class TestCustom:
    def setup(self):
        self.url_custom = '/api/extras/custom-fields/'

    @staticmethod
    def set_custom_payload(name, key):
        payload = {
            "label": name,
            'description': 'Created by Load Test Data Script',
            'key': key,
            'types': 'Network',
            'type': {'value': 'select'},
            'weight': '100',
            'filter_logic': {'value': 'loose'},
            'content_types': ['dcim.device'],
            'status': 'Active'
        }
        return payload

    @staticmethod
    def set_custom_payload_choice(name, custom_id):
        payload = {
            'label': name,
            'weight': '100',
            'custom_field': {
                'id': custom_id
            },
            'value': name
        }
        return payload

    @staticmethod
    def get_object_id(http, response_results, apikey, end_point, search):
        header = {"Authorization": f'{apikey}'}
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?{search}")
        response_results(response)
        assert 'results' in response.json(), "Object was not found"
        id = response.json()['results'][0]['id']
        return id

    @staticmethod
    def update_record(module, payload, object_id):
        module.set_body(payload)
        response = module.put(object_id + '/')
        return response

    @staticmethod
    def create_record(module, payload):
        module.set_body(payload)
        response = module.post('')
        print(response.json())
        return response

    @pytest.mark.parametrize('test_data', ['test_data_load_custom'], indirect=True)
    def test_data_load_custom(self, http, test_data, response_results, apikey, response_asserts,
                                response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        names = ['ServiceNow Assignment Group', 'ServiceNow Device Type']
        key = ['servicenow_assignment_group', 'servicenow_device_type']
        header = {"Authorization": f'{apikey}'}

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for name, i in zip(names, key):
                print(name)
                print(i)
                name = f'{name}'
                payload = self.set_custom_payload(name, i)
                response = module.get(f"?label={name}")
                response_results(response)
                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    print(object_id)

                else:
                    response = self.create_record(module, payload)
                    response_results(response, print_json_rows=False)
                    response_asserts(response, status_code=201)

    @pytest.mark.parametrize('test_data', ['test_data_load_choices'], indirect=True)
    def test_data_load_choices(self, http, test_data, response_results, apikey, response_asserts,
                               response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        choices = ['GNS Remote Connectivity Engineering', 'Firewall', 'Load Balancer', 'Router', 'Switch', 'Wireless Controller']
        header = {"Authorization": f'{apikey}'}
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)
            for choice in choices:
                response = module.get(f"?value={choice}")
                response_results(response)
                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    print(object_id)

                else:
                    header = {"Authorization": f'{apikey}'}
                    snw_assignment_id = self.get_object_id(http, response_results, apikey, self.url_custom + '{}',
                                                           f"label={'ServiceNow Assignment Group'}")
                    snw_device_id = self.get_object_id(http, response_results, apikey, self.url_custom + '{}',
                                                       f"label={'ServiceNow Device Type'}")
                    if choice == "GNS Remote Connectivity Engineering":
                        payload = self.set_custom_payload_choice(choice, snw_assignment_id)
                        response = self.create_record(module, payload)
                        response_results(response, print_json_rows=False)
                        response_asserts(response, status_code=201)
                    else:
                        payload = self.set_custom_payload_choice(choice, snw_device_id)
                        response = self.create_record(module, payload)
                        response_results(response, print_json_rows=False)
                        response_asserts(response, status_code=201)



