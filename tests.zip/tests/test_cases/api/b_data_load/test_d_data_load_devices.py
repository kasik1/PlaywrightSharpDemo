import pytest


@pytest.mark.data_load
class TestDevices:
    def setup(self):
        self.url_device_type = '/api/dcim/device-types/'
        self.url_device_role = '/api/extras/roles/'
        self.url_locations = '/api/dcim/locations/'
        self.url_racks = '/api/dcim/racks/'

    @staticmethod
    def update_record(module, payload, object_id, response_results, response_asserts):
        module.set_body(payload)
        response = module.put(object_id + '/')
        response_results(response, print_json_rows=False)
        response_asserts(response)
        return response

    @staticmethod
    def create_record(module, payload, response_results, response_asserts):
        module.set_body(payload)
        response = module.post('')
        response_results(response, print_json_rows=False)
        response_asserts(response, status_code=201)
        return response

    @staticmethod
    def get_object_id(http, response_results, apikey, end_point, search):
        header = {"Authorization": f'{apikey}'}
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?{search}")
        response_results(response)
        assert 'results' in response.json(), "Object was not found"
        id = response.json()['results'][0]['id']
        return id

    @staticmethod
    def set_payload_manufacturer(name, slug):
        payload = {
            'description': 'Created by Load Test Data Script',
            'slug': slug,
            'name': name
        }
        return payload

    @staticmethod
    def set_payload_device_type(model, manufacturer, slug):
        payload = {
            'comments': 'Created by Load Test Data Script',
            'manufacturer': manufacturer,
            'model': model,
            'slug': slug,
            'subdevice_role': {
                'value': 'parent',
                'label': 'Parent'
            },
        }
        return payload

    @staticmethod
    def set_payload_device_role(color, name, slug, content_types):
        payload = {
            'description': 'Created by Load Test Data Script',
            'color': color,
            'name': name,
            'slug': slug,
            'content_types': content_types
        }
        return payload

    @staticmethod
    def set_payload_platform(name_platform, slug_platform):
        payload = {
            'description': 'Created by Load Test Data Script',
            'name': name_platform,
            'slug': slug_platform
        }
        return payload

    @staticmethod
    def set_payload_device(data, name, asset_tag, serial_number, rack):
        payload = {
            'name': name,
            'location': data['location_id'],
            'role': data['role_id'],
            'device_type': data['device_type_id'],
            'rack': rack,
            'asset_tag': asset_tag,
            'serial': serial_number,
            'status': 'Planned',
            'comments': 'Created by Load Test Data Script',
            "custom_fields": {
                "ServiceNow Device Type": "-VG-"}
        }
        return payload

    @staticmethod
    def set_payload_virtual(name_virtual):
        payload = {
            'domain': 'load_test_data',
            'name': name_virtual,
        }
        return payload

    @pytest.mark.parametrize('test_data', ['test_data_load_manufacturer'], indirect=True)
    def test_data_load_manufacturer(self, http, test_data, response_results, apikey, response_asserts,
                                    response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for num in range(1, 4):
                name = f'Test-Manufacturer 0{num}'
                slug = f'test-manufacturer-0{num}'
                payload = self.set_payload_manufacturer(name, slug)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    self.update_record(module, payload, object_id, response_results, response_asserts)

                else:
                    self.create_record(module, payload, response_results, response_asserts)

    @pytest.mark.parametrize('test_data', ['test_data_load_device_type'], indirect=True)
    def test_data_load_device_type(self, http, test_data, response_results, apikey, response_asserts,
                                   response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}
        manufacturer = self.get_object_id(http, response_results, apikey, '/api/dcim/manufacturers/{}',
                                          "name=Test-Manufacturer 01")

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for num in range(1, 4):
                model = f'Test-Device type 0{num}'
                slug = f'test-device-type-0{num}'
                payload = self.set_payload_device_type(model, manufacturer, slug)
                response = module.get(f"?model={model}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    self.update_record(module, payload, object_id, response_results, response_asserts)

                else:
                    self.create_record(module, payload, response_results, response_asserts)

    @pytest.mark.parametrize('test_data', ['test_data_load_device_role'], indirect=True)
    def test_data_load_device_role(self, http, test_data, response_results, apikey, response_asserts,
                                   response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}
        colors = {
            1: '2196f3',  # Blue
            2: 'ff9800',  # Orange
            3: 'aa1409'}  # Dark red
        content_types = [
                'dcim.device',
            ]

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for num in range(1, 4):
                name = f'Test-Device Role 0{num}'
                slug = f'test-device-role-0{num}'
                color = colors[num]
                payload = self.set_payload_device_role(color, name, slug, content_types)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    self.update_record(module, payload, object_id, response_results, response_asserts)

                else:
                    self.create_record(module, payload, response_results, response_asserts)

    @pytest.mark.parametrize('test_data', ['test_data_load_platforms'], indirect=True)
    def test_data_load_platforms(self, http, test_data, response_results, apikey, response_asserts,
                                 response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for num in range(1, 4):
                name = f'Test-Platform 0{num}'
                slug = f'test-platform-0{num}'
                payload = self.set_payload_platform(name, slug)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    self.update_record(module, payload, object_id, response_results, response_asserts)

                else:
                    self.create_record(module, payload, response_results, response_asserts)

    @pytest.mark.parametrize('test_data', ['test_data_load_devices'], indirect=True)
    def test_data_load_devices(self, http, test_data, response_results, apikey, response_asserts,
                               response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}
        role_id = self.get_object_id(http, response_results, apikey, self.url_device_role+'{}',
                                     "name=Test-Device Role 01")
        device_type_id = self.get_object_id(http, response_results, apikey, self.url_device_type+'{}',
                                            "model=Test-Device type 01")
        location_id = self.get_object_id(http, response_results, apikey, self.url_locations+'{}',
                                         "name=QA-TD Location - view")
        racks = self.get_object_id(http, response_results, apikey, self.url_racks+'{}',
                                         "name=Test-Rack 01")
        data = {'location_id': location_id, 'role_id': role_id, 'device_type_id': device_type_id}

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for num in range(1, 4):
                name = f'Test-Device 0{num}'
                asset_tag = f"TEST-ASTDEV0{num}"
                serial_number = f"TEST-ASTDEV0{num}"
                payload = self.set_payload_device(data, name, asset_tag, serial_number, racks)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    self.update_record(module, payload, object_id, response_results, response_asserts)

                else:
                    self.create_record(module, payload, response_results, response_asserts)

    @pytest.mark.parametrize('test_data', ['test_data_load_virtual'], indirect=True)
    def test_data_load_virtual(self, http, test_data, response_results, apikey, response_asserts,
                               response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for num in range(1, 4):
                name = f'Test-Virtual chassis 0{num}'
                payload = self.set_payload_virtual(name)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    self.update_record(module, payload, object_id, response_results, response_asserts)

                else:
                    self.create_record(module, payload, response_results, response_asserts)
