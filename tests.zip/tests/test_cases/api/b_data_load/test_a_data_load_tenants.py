import pytest


@pytest.mark.data_load
class TestTenants:

    @staticmethod
    def set_payload(name, slug, desc):
        payload = {
            "name": name,
            "slug": slug,
            "description": desc
        }
        return payload

    @staticmethod
    def update_record(module, payload, object_id):
        module.set_body(payload)
        response = module.put(object_id + '/')
        return response

    @staticmethod
    def create_record(module, payload):
        module.set_body(payload)
        response = module.post('')
        return response

    @pytest.mark.parametrize('test_data', ['test_data_load_tenant_groups'], indirect=True)
    def test_data_load_tenant_groups(self, http, test_data, response_results, apikey, response_asserts,
                                     response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        names = ['view', 'update', 'delete']
        desc = 'Load test data record'
        header = {"Authorization": f'{apikey}'}
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for name in names:
                slug = f'qa-td-tenant-group-{name}'
                name = f'QA-TD Tenant group - {name}'
                payload = self.set_payload(name, slug, desc)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    response = self.update_record(module, payload, object_id)
                    response_results(response, print_json_rows=False)
                    response_asserts(response)

                else:
                    response = self.create_record(module, payload)
                    response_results(response, print_json_rows=False)
                    response_asserts(response, status_code=201)

    @pytest.mark.parametrize('test_data', ['test_data_load_tenants'], indirect=True)
    def test_data_load_tenants(self, http, test_data, response_results, apikey, response_asserts,
                               response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        names = ['view', 'update', 'delete']
        desc = 'Load test data record'
        header = {"Authorization": f'{apikey}'}
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for name in names:
                slug = f'qa-td-tenant-{name}'
                name = f'QA-TD Tenant - {name}'
                payload = self.set_payload(name, slug, desc)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    response = self.update_record(module, payload, object_id)
                    response_results(response, print_json_rows=False)
                    response_asserts(response)

                else:
                    response = self.create_record(module, payload)
                    response_results(response, print_json_rows=False)
                    response_asserts(response, status_code=201)
