import pytest


@pytest.mark.smoke
class TestProviderNetworksResponseSmokeTesting:
    @pytest.mark.parametrize('test_data', ['test_get_provider_networks'], indirect=True)
    def test_get_provider_networks(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['results']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(end_point)
            module.set_headers(header)
            response = module.get()
            response_results(response)
            response_asserts(response)
            response_assert_fields(response, response_fields)


@pytest.mark.parallel
@pytest.mark.functional
class TestProviderNetworks:

    def setup(self):
        self.url_provider_networks = '/api/circuits/provider-networks/'
        self.url_providers = '/api/circuits/providers/'

    @staticmethod
    def create_entry_for_testing(http, row, end_point, get_id_provider, apikey, return_id=True):
        """ This method creates the payload to be sent in the rquest of the following test cases,
                Payload : is the set of data that will be sent to generate the intake ticket
                Module : contains the instruction for the execution of the method to be carried out, example: post (), get () etc.
                Response : contains the response after the post was executed, or get
                Create an if : this looks for the id tag in the respons to check that the pyload was generated correctly"""
        module = http(end_point)
        header = {"Authorization": f'{apikey}',
                  'Content-type': 'application/json'}
        payload = {
                "provider": get_id_provider,
                "name": row['name'],
                "natural_slug": row['slug'],
                "description": row['desc'],
                "comments": row['desc'],
                "custom_fields": {}}
        module.set_headers(header)
        module.set_body(payload)
        response = module.post()
        if return_id:
            assert 'id' in response.json(), "New Automation Request entry for testing was not created successfully."
            return response.json()['id']

    @pytest.mark.parametrize('test_data', ['test_get_provider_networks_id'], indirect=True)
    def test_get_provider_networks_id(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey, get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['id', 'name', 'description', 'comments']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_provider_networks)
            module.set_headers(header)
            response = module.get()
            if not response.json()['results']:
                module_2 = http(self.url_providers)
                module_2.set_headers(header)
                get_id_provider = get_object_id(module_2)
                self.create_entry_for_testing(http, row, '/api/circuits/provider-networks/',
                                                          get_id_provider=get_id_provider, apikey=apikey)
            get_id_provider_net = get_object_id(module)
            module = http(end_point)
            module.set_headers(header)
            response = module.get(get_id_provider_net)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, response_fields)

    @pytest.mark.parametrize('test_data', ['test_post_create_provider_networks'], indirect=True)
    def test_post_create_provider_networks(self, http, test_data, response_results, apikey, response_asserts,
                                            response_assert_fields, get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            response_fields = ['id', 'name', 'description', 'comments']
            end_point = row['ENDPOINT']
            header = {"Authorization": f'{apikey}',
                'Content-type': 'application/json'}
            module = http(self.url_providers)
            module.set_headers(header)
            get_id_provider = get_object_id(module)
            payload = {
                "provider": get_id_provider,
                "name": row['name'],
                "natural_slug": row['slug'],
                "description": row['desc'],
                "comments": row['desc'],
                "custom_fields": {}}
            module = http(end_point)
            module.set_body(payload)
            module.set_headers(header)
            response = module.post()
            response_results(response, print_json_rows=False)
            response_asserts(response, status_code=201)
            response_assert_fields(response, response_fields)
            object_id = response.json()['id']
            get_end_point = '/api/circuits/provider-networks/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

    @pytest.mark.parametrize('test_data', ['test_put_update_provider_networks'], indirect=True)
    def test_put_update_provider_networks(self, http, test_data, response_results, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_provider_networks)
            module.set_headers(header)
            get_id_provider_net = get_object_id(module)
            get_provider = get_object_data(module, "provider")
            get_provider = get_provider['id']
            get_name = get_object_data(module, "name")
            module = http(end_point)
            payload = [{
                "id": get_id_provider_net,
                "provider": get_provider,
                "name": get_name,
                "description": row['desc'],
                "comments": row['desc'],
                "custom_fields": {}}]
            module.set_headers(header)
            module.set_body(payload)
            response = module.put()
            response_results(response, print_json_rows=False)
            assert response.json()[0]['id'] == get_id_provider_net, f"ID from response does not match expected ID {get_id_provider_net}."
            assert response.json()[0]['name'] == get_name, f"Name from response does not match expected Name {get_name}."

    @pytest.mark.parametrize('test_data', ['test_put_update_provider_networks_id'], indirect=True)
    def test_put_update_provider_networks_id(self, http, test_data, response_results, response_asserts,
                                           response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_provider_networks)
            module.set_headers(header)
            get_id_provider_net = get_object_id(module)
            get_name = get_object_data(module, "name")
            get_provider = get_object_data(module, "provider")
            get_provider = get_provider['id']
            module = http(end_point)
            payload = {
                "provider": get_provider,
                "name": get_name,
                "description": row['desc'],
                "comments": row['desc'],
                "custom_fields": {}}
            module.set_headers(header)
            module.set_body(payload)
            response = module.put(get_id_provider_net)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, payload)
            assert response.json()['name'] == get_name, f"Nam from response does not match expected Name {get_name}."
            assert response.json()['id'] == get_id_provider_net, f"The Json accep.is not equal{get_id_provider_net}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_provider_networks'], indirect=True)
    def test_patch_update_provider_networks(self, http, test_data, response_results, get_object_id, get_object_data, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_provider_networks)
            module.set_headers(header)
            get_id_provider_net = get_object_id(module)
            get_name = get_object_data(module, "name")
            get_provider = get_object_data(module, "provider")
            get_provider = get_provider['id']
            module = http(end_point)
            payload = [{
                "id": get_id_provider_net,
                "provider": get_provider,
                "name": get_name,
                "description": row['desc'],
                "comments": row['desc'],
                "custom_fields": {}}]
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch()
            response_results(response, print_json_rows=False)
            assert response.json()[0]['id'] == get_id_provider_net, f"ID from response does not match expected ID {get_id_provider_net}."
            assert response.json()[0]['name'] == get_name, f"Name from response does not match expected Name {get_name}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_provider_networks_id'], indirect=True)
    def test_patch_update_provider_networks_id(self, http, test_data, response_results, response_asserts,
                                   response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_provider_networks)
            module.set_headers(header)
            get_id_provider_net = get_object_id(module)
            get_name = get_object_data(module, "name")
            get_provider = get_object_data(module, "provider")
            get_provider = get_provider['id']
            module = http(end_point)
            payload = {
                "provider": get_provider,
                "name": get_name,
                "description": row['desc'],
                "comments": row['desc'],
                "custom_fields": {}}
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch(get_id_provider_net)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, payload)
            assert response.json()['name'] == get_name, f"Name from response does not match expected Name {get_name}."
            assert response.json()['id'] == get_id_provider_net, f"ID from response does not match expected ID{get_id_provider_net}."

    @pytest.mark.parametrize('test_data', ['test_delete_provider_networks'], indirect=True)
    def test_delete_provider_networks(self, http, test_data, response_results, response_asserts,
                                       response_assert_fields,apikey, get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            header = {"Authorization": f'{apikey}'}
            module = http(self.url_providers)
            module.set_headers(header)
            get_id_provider = get_object_id(module)
            object_id = self.create_entry_for_testing(http, row, '/api/circuits/provider-networks/', get_id_provider=get_id_provider, apikey=apikey)
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

            get_end_point = '/api/circuits/provider-networks/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.get(object_id)
            assert response.status_code == 404, "The status code not is equal at 404"
            assert response.json()['detail'] == 'No ProviderNetwork matches the given query.', "The Request wasn't deleted."
