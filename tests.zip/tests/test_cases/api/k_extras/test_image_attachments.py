import pytest
import os


class Extras:
    def setup(self):
        self.end_point = '/api/extras/image-attachments/'
        self.url_locations = "/api/dcim/locations/"

    def set_payload(self, row, get_location):
        payload = {
            'content_type': row['content_types'],
            'object_id': get_location,
            'name': row['name'],
            'image_height': row['image_height'],
            'image_width': row['image_width']}
        return payload

    @staticmethod
    def get_image_path():
        path = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(path, 'site.png')

    @staticmethod
    def get_object_id(http, apikey, end_point, search):
        header = {"Authorization": f'{apikey}'}
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?{search}")
        assert 'results' in response.json(), "Object was not found"
        id = response.json()['results'][0]['id']
        return id

@pytest.mark.smoke
class TestImageAttachmentsSmokeTesting(Extras):
    """
    Smoke Testing
    """
    @pytest.mark.parametrize('test_data', ['test_get_image_attachments'], indirect=True)
    def test_get_image_attachments(self, http, test_data, response_results, response_asserts, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        """
        header = {
            "Authorization": f'{apikey}'}
        module = http(self.end_point)
        module.set_headers(header)
        response = module.get()
        response_results(response, print_json_rows=False)
        response_asserts(response)

@pytest.mark.manual
class TestImageAttachments(Extras):
    """
    Integration Testing
    """
    def create_entry_for_testing(self, http, row, apikey, return_id=True):
        """ This method creates the payload to be sent in the request of the following test cases,
        :param http: Endpoint Class which contains requests methods
        :param row: Test Data Row from the csv file
        :param apikey: Token to get access to the endpoints
        :param return_id: Boolean variable to return or not the created id
        """
        header = {
            "Authorization": f'{apikey}'}
        module = http(self.end_point)
        payload = self.set_payload(row)
        module.set_headers(header)
        module.set_body(payload)
        module.set_attachment(file_name='image', file_path=self.get_image_path())
        response = module.post_with_image()
        if return_id:
            assert 'id' in response.json(), 'New Record for testing was not created successfully'
            return response.json()['id']

    def delete_method(self, http, object_id, apikey):
        headers = {"Authorization": f'{apikey}'}
        module = http(self.end_point + f'{object_id}/')
        module.set_headers(headers)
        response = module.delete()
        assert response.status_code == 204

    @pytest.mark.skip
    @pytest.mark.parametrize('test_data', ['test_post_image_attachment'], indirect=True)
    def test_post_image_attachment(self, http, test_data, response_results, response_asserts, apikey):
        """
        Post image attachment
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        """
        get_location = self.get_object_id(http, apikey, self.url_locations + '{}',
                                          "name=QA-TD Location - view")
        print("id", get_location)
        for row in test_data['data']:
            header = {
                "Authorization": f'{apikey}',
                "Content-type": 'application/json'}
            module = http(self.end_point)
            payload = self.set_payload(row, get_location)
            module.set_headers(header)
            module.set_body(payload)
            module.set_attachment(file_name='image', file_path=self.get_image_path())
            response = module.post_with_image()
            print("rep", response.json())
            response_results(response, print_json_rows=False, print_json=False)
            response_asserts(response, status_code=201)
            created_id = response.json()['id']
            self.delete_method(http, created_id, apikey)

    @pytest.mark.skip
    @pytest.mark.parametrize('test_data', ['test_get_single_image_attachment'], indirect=True)
    def test_get_single_image_attachment(self, http, test_data, response_results, apikey, response_asserts):
        """
        Get single image attachments
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            created_id = self.create_entry_for_testing(http, row, apikey)
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.end_point + f'{created_id}/')
            module.set_headers(header)
            response = module.get()
            print(response.json())
            response_results(response, print_json_rows=False)
            response_asserts(response)
            self.delete_method(http, created_id, apikey)

    @pytest.mark.skip
    @pytest.mark.parametrize('test_data', ['test_put_single_image_attachment'], indirect=True)
    def test_put_single_image_attachment(self, http, test_data, response_results, apikey, response_asserts):
        """
        Update Put single image attachments
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            created_id = self.create_entry_for_testing(http, row, apikey)
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.end_point + f'{created_id}/')
            module.set_headers(header)
            payload = {**self.set_payload(row), **{'id': created_id}}
            module.set_body(payload)
            module.set_attachment(file_name='image', file_path=self.get_image_path())
            response = module.put_with_image()
            response_results(response, print_json_rows=False)
            response_asserts(response)
            self.delete_method(http, created_id, apikey)

    @pytest.mark.skip
    @pytest.mark.parametrize('test_data', ['test_patch_single_image_attachment'], indirect=True)
    def test_patch_single_image_attachment(self, http, test_data, response_results, apikey, response_asserts):
        """
        Update Patch single image attachments
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            created_id = self.create_entry_for_testing(http, row, apikey)
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.end_point + f'{created_id}/')
            module.set_headers(header)
            payload = {**self.set_payload(row), **{'id': created_id}}
            module.set_body(payload)
            module.set_attachment(file_name='image', file_path=self.get_image_path())
            response = module.patch_with_image()
            response_results(response, print_json_rows=False)
            response_asserts(response)
            self.delete_method(http, created_id, apikey)

    @pytest.mark.skip
    @pytest.mark.parametrize('test_data', ['test_delete_single_image_attachment'], indirect=True)
    def test_delete_single_image_attachment(self, http, test_data, response_results, apikey, response_asserts):
        """
        Delete single image attachments
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            created_id = self.create_entry_for_testing(http, row, apikey)
            self.delete_method(http, created_id, apikey)
