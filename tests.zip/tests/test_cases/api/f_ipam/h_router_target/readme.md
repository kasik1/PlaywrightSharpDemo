Router Targets API v1 - Test Suite Folder
=============

* **Testing type:** API Testing
* **Branch name:** E378_scripts_test_data_load



#### Folder Structure

1. **conftest.py:** Includes configuration and methods for Pytest and the test suite.
2. **test_data.csv:** Contains the Test Data for the Tests.
3. **test_suite.py:** Script with the set of the Test Cases.


#### Documentation

For more information of this Test Suite please refer to the [Confluence Documentation] [id].

[id]: https://confluence.sys.cigna.com/display/NetDevOps/Test+Design+-+Network+Infrastructure+Manager%3A+Router+Targets