import os
from tests.fixtures.users import create_login
import pytest


class Providers:
    def setup(self):
        self.ADD_OK = "Created provider"
        self.UPDATE = "Modified provider"
        self.ADD_URL = "/circuits/providers/add/"
        self.delete_circuit_provider = "Deleted provider"


@pytest.mark.parametrize('user_session', [*create_login()])
@pytest.mark.userbase
class TestProvidersUserBase(Providers):

    @pytest.mark.parametrize('test_data', ['test_view_title_providers'], indirect=True)
    def test_view_title_providers(self, user_base, test_data, user_session, login_page):
        """ providers - Test check the title in the menu the tenants """
        title = 'Providers'
        user_base.log_out()
        login_page(user_session)
        user_base.providers_page()
        assert user_base.is_title_present(title, type='h1')
        user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_add_providers'], indirect=True)
    def test_add_providers(self, user_base, test_data, user_session, login_page):
        """ providers - Add a Device Tenant Group. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            user_base.providers_page()
            user_base.click_add_button()
            user_base.set_provider_data(data=row)
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_update_element_providers'], indirect=True)
    def test_update_element_providers(self, user_base, test_data,login_page, user_session):
        """ providers - Update a Tenant Group  with the required fields by model. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            found_contact = user_base.search_provider(row['PROVIDER'])
            assert found_contact, f"No circuit with name {row['PROVIDER']} found."
            user_base.edit_provider(row['PROVIDER'], data=row)
            assert user_base.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_action_delete_providers'], indirect=True)
    def test_action_delete_providers(self, user_base, test_data, user_session, login_page):
        """ providers - Delete a Tenant Group type by model. """
        user_base.log_out()
        login_page(user_session)
        user_base.manufacturers_page()
        user_base.view_first_record_of_table()
        user_base.click_delete_button()
        user_base.log_out()


@pytest.mark.smoke
class TestProvidersFormSmokeTesting:

    @pytest.mark.parametrize('test_data', ['test_search_specific_provider'], indirect=True)
    def test_search_the_module(self, ssot, test_data):
        """ search the module providerS  """
        title = 'Providers'
        ssot.providers_page()
        assert ssot.is_title_present(title, type='h1')
        ssot.view_first_record_of_table()
        assert ssot.title_present(name="Provider")
        

@pytest.mark.parallel
@pytest.mark.functional
class TestProviders(Providers):
    """Class for the Provider module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_add_provider'], indirect=True)
    def test_add_provider(self, ssot, test_data):
        """ Provider - Add a Provider. """
        for row in test_data['data']:
            ssot.add_providers(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."

    @pytest.mark.parametrize('test_data', ['test_provider_missing'], indirect=True)
    def test_provider_missing(self, ssot, test_data):
        """ Provider - Try to add a Circuits without the required fields. """
        for row in test_data['data']:
            ssot.add_providers(data=row)
            assert ssot.check_url(self.ADD_URL), "The add alert is present."

    @pytest.mark.parametrize('test_data', ['test_view_provider_details'], indirect=True)
    def test_view_provider_details(self, ssot, test_data):
        """ Provider - View Provider details """
        ssot.providers_page()
        ssot.view_first_record_of_table()
        assert ssot.title_present(name="Provider")
        ssot.are_provider_stats_present()

    @pytest.mark.parametrize('test_data', ['test_view_change_log'], indirect=True)
    def test_view_change_log(self, ssot, test_data):
        """ View the change log table for a record """
        for row in test_data['data']:
            found_contact = ssot.search_provider(row['PROVIDER'])
            assert found_contact, f"No contact with name {row['PROVIDER']} found."
            ssot.click_link_text(row['PROVIDER'])
            ssot.go_to_tab('Change Log')
            assert ssot.is_log_table_present()

    @pytest.mark.parametrize('test_data', ['test_update_provider'], indirect=True)
    def test_update_provider(self, ssot, test_data):
        """ Provider - Update a Provider with the required fields by model. """
        for row in test_data['data']:
            found_contact = ssot.search_provider(row['PROVIDER'])
            assert found_contact, f"No circuit with name {row['PROVIDER']} found."
            ssot.edit_provider(row['PROVIDER'], data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form'], indirect=True)
    def test_required_fields_edit_form(self, ssot, test_data):
        """ Provider - test_load_data_edit in tenants with the required fields by model. """
        for row in test_data['data']:
            ssot.providers_page()
            found_contact = ssot.search_provider(row['PROVIDER'])
            assert found_contact, f"No circuit with name {row['PROVIDER']} found."
            data1, data2, data3 = ssot.get_info_table_edit(values=["Name", "ASN", "Account number"])
            ssot.click_link_text(row['PROVIDER'])
            ssot.click_edit_button()
            input_values = ssot.get_input_values_form_edit(["Name", "ASN", "Account number"])
            assert all(element in (data1, data2, data3) for element in input_values), "in the edit view the required" \
                                                                         " fields were not loaded, and the " \
                                                                         "assert fails because it cannot " \
                                                                         "find the value in the form"

    @pytest.mark.parametrize('test_data', ['test_delete_provider'], indirect=True)
    def test_delete_provider(self, ssot, test_data):
        """ Provider - Delete a Provider by model. """
        for row in test_data['data']:
            found_contact = ssot.search_provider(row['PROVIDER'])
            assert found_contact, f"No circuit with name {row['PROVIDER']} found."
            ssot.delete_provider(row['PROVIDER'])
            assert ssot.check_alert_text(self.delete_circuit_provider), f"The alert text is not {self.delete_circuit_provider} as we expected."


@pytest.mark.exports
class TestProvidersExports:
    @pytest.mark.parametrize('test_data', ['test_export_providers'], indirect=True)
    def test_export_providers(self, ssot, test_data, rename_download):
        """ provider - export csv the current view. """
        ssot.providers_page()
        ssot.click_export_button()
        ssot.export_current_view()

    @pytest.mark.parametrize('test_data', ['test_check_export_providers'], indirect=True)
    def test_check_export_providers(self, ssot, test_data, rename_download):
        """ provider - chek the csv in local machine"""
        ssot.providers_page()
        data = ssot.get_data_for_check_export(2)
        file_name = 'provider_export.csv'
        rename_download(name=file_name)
        file_path = os.path.join(os.getcwd(), file_name)
        assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
        csv = ssot.read_csv(file_name)
        assert ssot. check_csv_and_data(data,csv)
        os.remove(file_path)