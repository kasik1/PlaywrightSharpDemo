import os
import pytest


@pytest.mark.smoke
class TestDeviceIndicatorsST:
    def setup(self):
        self.Device_icmp_value = "False"
        self.Device_snmp_value = "True"
        self.Device_empty_value = "-"

    @pytest.mark.parametrize('test_data', ['test_show_module'], indirect=True)
    def test_show_module(self, ssot, test_data):
        """
        Test module is present
        """
        ssot.device_indicators_page()
        assert ssot.is_title_present('Device Indicator', type='h1', timeout=60)

    @pytest.mark.parametrize('test_data', ['test_show_table'], indirect=True)
    def test_show_table(self, ssot, test_data):
        """
        Test module is present
        """
        ssot.device_indicators_page()
        if ssot.check_headers_table(["Device"]):
            headers = ["Device", "Last updated", "Assure1", "ServiceNow", "SevOne"]
            assert ssot.is_title_present('Device Indicator', type='h1', timeout=60)
            assert ssot.check_headers_table(headers)


@pytest.mark.functional
@pytest.mark.parallel
class TestDeviceIndicatorsFT(TestDeviceIndicatorsST):

    @pytest.mark.parametrize('test_data', ['test_view_device_details '], indirect=True)
    def test_view_device_details(self, ssot, test_data):
        """ View record details """
        ssot.device_indicators_page()
        name = ssot.view_first_record_of_table()
        ssot.switch_page(name)

    @pytest.mark.parametrize('test_data', ['test_view_app_installed '], indirect=True)
    def test_view_app_installed(self, ssot, test_data):
        """ View record details """
        title = 'Device Indicator Plugin'
        ssot.installed_apps_page()
        assert ssot.is_title_present(title, type='a')
        ssot.click_plugin_install(title, type='a')
        assert ssot.assert_version != ""

    @pytest.mark.parametrize('test_data', ['test_view_info_last_update'], indirect=True)
    def test_view_info_last_update(self, ssot, test_data):
        """ View record details """

        ssot.device_indicators_page()
        last_update_table = ssot.get_last_update()
        if last_update_table != "—":
            ssot.view_first_record_of_table()
            last_update_device = ssot.get_last_update_device()
            assert last_update_table == last_update_device or "None"

    @pytest.mark.parametrize('test_data', ['test_device_indicator_filter'], indirect=True)
    def test_device_indicator_filter(self, ssot, test_data, setup_server_url):
        """ Test Device Filter:- Select and clear filters. - Validate that the filter is applied correctly
         - Ensure the filter is removed when cleared.
        """
        ssot.home_page(setup_server_url)
        ssot.device_indicator()
        ssot.go_filters()
        filter_count = ssot.get_total_filter_count()
        for filter_index in range(1, filter_count + 1):
            filter_applied = ssot.select_device_filter(1, filter_index)
            if filter_applied:
                ssot.click_apply_filter_button()
                current_url = ssot.get_current_url()
                if current_url.endswith('?'):
                    assert '?' in current_url, "Filter values are empty or not applied"
                else:
                    selected_filter = ssot.get_selected_filter_value(1)
                    assert selected_filter in current_url, f"Expected '{selected_filter}'in URL, but got: {current_url}"
                    ssot.click_clear_filters()
                    ssot.go_filters()
        ssot.click_apply_filter_button()
        ssot.input_search_filters("unclaimed")
        ssot.search_button_filters()
        search_string = "unclaimed"
        current_url = ssot.get_current_url()
        assert search_string in current_url, f"Expected '{search_string}' in URL, but got: {current_url}"

    @pytest.mark.parametrize('test_data', ['test_device_indicator_update_filter'], indirect=True)
    def test_device_indicator_update_filter(self, ssot, test_data, setup_server_url):
        """ Test Device Indicator Update Filter: - Validate that updating a filter does not change the previous
         filters."""
        ssot.home_page(setup_server_url)
        ssot.device_indicator()
        ssot.go_filters()
        filter_count = ssot.get_total_filter_count()
        ssot.click_apply_filter_button()
        ssot.go_filters()
        applied_filters = 0
        for filter_index in range(1, filter_count + 1):
            filter_applied = ssot.select_device_filter(1, filter_index)
            if filter_applied:
                ssot.click_apply_filter_button()
                selected_filter = ssot.get_applied_filter_count()
                if selected_filter > applied_filters:
                    applied_filters = selected_filter  # Update count only if filter applied
                assert selected_filter == applied_filters, \
                    f"Filter count mismatch! Expected {applied_filters}, but got {selected_filter}"
                ssot.go_filters()

    @pytest.mark.parametrize('test_data', ['test_device_indicator_update_multi_filters_location_adc'], indirect=True)
    def test_device_indicator_update_multi_filters_location_adc(self, ssot, test_data):
        """ Test Device Indicator Update Filter location adc, satus,production role Access Point,
        service group GNS Remote Connectivity Support, -Validate that updating a filter does not change the previous
                filters."""
        path = os.path.dirname(os.path.abspath(__file__))
        select_file = os.path.join(path, 'devices_filter.csv')
        location_adc = ssot.get_filter_values_from_csv(select_file, 'location_name', 0)
        statu_production = ssot.get_filter_values_from_csv(select_file, 'status__name', 0)
        role_access_pont = ssot.get_filter_values_from_csv(select_file, 'role__name', 0)
        service = ssot.get_filter_values_from_csv(select_file, 'cf_servicenow_assignment_group', 0)
        device_value = ssot.get_filter_values_from_csv(select_file, 'filter_value', 0)
        ssot.device_indicator()
        ssot.go_filters()
        ssot.select_multi_filters(location_adc, statu_production, role_access_pont, service)
        ssot.click_apply_filter_button()
        assert ssot.get_filtered_results_count() > 0, "no results found after applying  filters"
        assert ssot.get_filtered_results_text() == device_value
        ssot.clear_all_filters()

    @pytest.mark.parametrize('test_data', ['test_device_indicator_new_fields'], indirect=True)
    def test_device_indicator_new_fields(self, ssot, test_data):
        """ Test Device Indicator-Validate that new device_indicator fields values icmp,snmp are displaying ."""
        ssot.device_indicator()
        ssot.click_on_device()
        expected = [self.Device_snmp_value, self.Device_snmp_value, self.Device_empty_value]
        assert (ssot.get_device_icmp_enabled_status(), expected), "Invalid ICMP value"
        assert ssot.is_field_valid_status(ssot.get_device_icmp_working_status(), expected), "Invalid ICMP Working value"
        assert ssot.is_field_valid_status(ssot.get_device_snmp_enabled_status(), expected), "Invalid SNMP value"
        assert ssot.is_field_valid_status(ssot.get_device_snmp_working_status(), expected), "Invalid SNMP Working value"
