import pytest


class InventoryList:

    def setup(self):
        self.ADD_OK = "Created device"
        self.ADD_URL = "/inventory-add/"
        self.UPDATE = "Modified device"
        self.DELETE = "Deleted device"


@pytest.mark.smoke
class TestInventoryListFormSmokeTesting:

    @pytest.mark.parametrize('test_data', ['test_show_module'], indirect=True)
    def test_show_module(self, ssot, test_data):
        """ Contracts - Search a contracts by name. """
        ssot.inventory_list_page()
        assert ssot.is_title_present('Device', type='h1', timeout=60)

    @pytest.mark.parametrize('test_data', ['test_show_table'], indirect=True)
    def test_show_table(self, ssot, test_data):
        """ Contracts - Search a contracts by name. """
        ssot.inventory_list_page()
        if ssot.check_headers_table(["Name"]):
            headers = ["Name", "Status", "Tenant", "Role", "Device type", "Location", "Rack", "Primary ip"]
            assert ssot.check_headers_table(headers)


@pytest.mark.parallel
@pytest.mark.functional
class TestInventoryList(InventoryList):
    """Class for the contracts module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_status_inventory_device'], indirect=True)
    def test_status_inventory_device(self, ssot, test_data,setup_server_url):
        for row in test_data['data']:
            ssot.home_page(setup_server_url)
            ssot.devices_page()
            found_contact = ssot.search_device(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.edit_device(row['NAME'], data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."
            assert ssot.search_inventory_lis(row['NAME'])

    @pytest.mark.parametrize('test_data', ['test_add_inventory'], indirect=True)
    def test_add_inventory(self, ssot, test_data):
        """ Contracts - Add a Contract. """
        for row in test_data['data']:
            ssot.add_inventory_list(data=row)
            found_contact = ssot.search_device(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.click_link_text(row['NAME'])
            ssot.click_delete_button()
            ssot.click_confirm_button()

    @pytest.mark.parametrize('test_data', ['test_add_inventory_missing_fields'], indirect=True)
    def test_add_inventory_missing_fields(self, ssot, test_data):
        """ Contracts - Try to add a item without the required fields.
        """
        for row in test_data['data']:
            ssot.add_inventory_list(data=row)
            assert ssot.check_url(self.ADD_URL), "The add alert is present."

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form_inventory'], indirect=True)
    def test_required_fields_edit_form_inventory(self, ssot, test_data, setup_server_url):
        """ Devices - test_load_data_edit in device."""
        ssot.go_url(setup_server_url)
        ssot.inventory_list_page()
        data1 = ssot.get_info_table_edit(values=['Name', 'Role', 'Device type', 'Location', 'Rack'])
        elements = data1
        ssot.click_link_text(data1[0])
        ssot.click_edit_button()
        select_values = ssot.get_select_values_form_edit(['Location', 'Device type', 'Role'])
        input_values = ssot.get_input_values_form_edit(['Name'])
        assert all(element in elements for element in select_values + input_values), "in the edit view the required" \
                                                                                     " fields were not loaded, and the " \
                                                                                     "assert fails because it cannot " \
                                                                                     "find the value in the form"

    @pytest.mark.parametrize('test_data', ['test_update_interface'], indirect=True)
    def test_update_interface(self, ssot, test_data):
        """ Devices - Update a device with the required fields by name. """
        for row in test_data['data']:
            found_contact = ssot.search_inventory_lis(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.edit_inventory(row['NAME'], data=row)
            assert ssot.check_title_dev(row['NAME']), f"The text is not {row['NAME']} as we expected."

    @pytest.mark.parametrize('test_data', ['test_delete_inventory_device'], indirect=True)
    def test_delete_inventory_device(self, ssot, test_data):
        for row in test_data['data']:
            ssot.devices_page()
            found_contact = ssot.search_device(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.edit_device(row['NAME'], data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."
            assert not ssot.search_inventory_lis(row['NAME'])



