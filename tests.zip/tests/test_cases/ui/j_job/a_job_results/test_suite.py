import string
import random
import pytest
import os


class Job_Results:

    def setup(self):
        self.export_object = "Export Object List"
        self.sevone = "SevOne to Nautobot"
        self.message_serverone = "Loading data from SevOne instance"
        self.message_export = "Exporting "
        self.level_info = "Info"
        self.missing_device_job = "ReportMissingDevicesJob"
        self.update_device_job = "CI Needs Update Report"
        self.duplicate_device_job = "CMDB Duplicate CI Report"
        self.update_job_name = 'Ci needs update report email addressess'
        self.missing_job_name = 'Missing devices report email addressess'
        self.duplicate_job_name = 'Duplicated ci report email addressess'
        self.job_status_success = "Completed"
        self.job_status_Failed = "Failed"
        self.delete = "was deleted successfully"


@pytest.mark.smoke
class TestJobResultsSmoke:

    @pytest.mark.parametrize('test_data', ['test_title_page'], indirect=True)
    def test_title_page(self, ssot, test_data):
        """ Contracts - Search a contracts by name. """
        ssot.job_results_page()

    @pytest.mark.parametrize('test_data', ['test_main_job_results'], indirect=True)
    def test_main_job_results(self, ssot, test_data):
        """ Contracts - Search a contracts by name. """
        ssot.job_results_page()
        ssot.table_titles()


@pytest.mark.parallel
@pytest.mark.functional
class TestJobResults(Job_Results):
    """Class for the contracts module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_view_summary'], indirect=True)
    def test_view_summary(self, ssot, test_data):
        """ Contracts - Add a Contract. """
        ssot.job_results_page()
        ssot.view_first_job()
        assert ssot.verify_card_sumary()

    @pytest.mark.parametrize('test_data', ['test_data_loading_serveone'], indirect=True)
    def test_data_loading_serveone(self, ssot, test_data):
        """ Contracts - Try to add a item without the required fields.
        """
        found_job = ssot.search_device(self.sevone)
        if found_job:
            ssot.click_on_job_model(self.sevone)
            ssot.check_message(self.message_serverone)
            check_points = ssot.check_level(self.message_serverone, self.level_info)
            assert check_points

    @pytest.mark.parametrize('test_data', ['test_data_loading_export'], indirect=True)
    def test_data_loading_export(self, ssot, test_data):
        """ View record details """
        found_job = ssot.search_device(self.export_object)
        if found_job:
            ssot.click_on_job_model(self.export_object)
            ssot.check_message(self.message_export)
            check_points = ssot.check_level(self.message_export, self.level_info)
            assert check_points

    @pytest.mark.parametrize('test_data', ['test_existence_file_output'], indirect=True)
    def test_existence_file_output(self, ssot, test_data):
        """ Contracts - Update a contracts with the required fields by name. """
        found_job = ssot.search_device(self.export_object)
        if found_job:
            ssot.click_on_job_model(self.export_object)
            file = ssot.view_file_output()
            assert file

    @pytest.mark.parametrize('test_data', ['test_add_invalid_address_cmdb'], indirect=True)
    def test_add_invalid_address_cmdb(self, ssot, test_data):
        """
        Test to verify add as empty address  value in CMDB Missing device Report.
        Steps:
        1. Navigate to device email address page.
        2. add empty  address value
        3. Run job and verify job fails.
        4. deleted  empty address value
        """
        ssot.navigate_to_device_email_page(self.missing_job_name)
        ssot.add_and_clear_email()
        ssot.search_and_run_job(self.missing_device_job)
        status = ssot.get_job_status(self.job_status_Failed)
        assert status == self.job_status_Failed, f"Expected status Failed, got {status}"
        ssot.navigate_to_device_email_page(self.missing_job_name)
        ssot.delete_and_confirmation_button()
        assert self.delete in ssot.get_delete_devices_alert_text(), f"The  text is not {self.delete} as we expected."

    @pytest.mark.parametrize('test_data', ['test_run_cmdb_missing_device_report_job_successfully'], indirect=True)
    def test_run_cmdb_missing_device_report_job_successfully(self, ssot, test_data):
        """ Test to verify CMDB Missing device report job runs successfully with correct email address """
        ssot.search_and_run_job(self.missing_device_job)
        assert ssot.get_job_status(self.job_status_success) == self.job_status_success, f"Expected status Completed got \
            {self.job_status_success}"

    @pytest.mark.parametrize('test_data', ['test_run_cmdb_update_device_report_job_successfully'], indirect=True)
    def test_run_cmdb_update_device_report_job_successfully(self, ssot, test_data):
        """ Test to verify CMDB devices Needing Updates report job runs successfully with correct email address"""
        ssot.search_and_run_job(self.update_device_job)
        assert ssot.get_job_status(self.job_status_success) == self.job_status_success, f"Expected status Completed got \
            {self.job_status_success}"

    @pytest.mark.parametrize('test_data', ['test_add_invalid_address_cmdb_update_device_job'],  indirect=True)
    def test_add_invalid_address_cmdb_update_device_job(self, ssot, test_data):
        """
            Test to verify add as empty address value in Ci needs update report email addresses run the job and verify
             job fails.
               Steps:
               1. Navigate to update device email address page.
               2. add empty  address value
               3. Run job and verify job fails.
               4. deleted  empty address value
        """
        ssot.navigate_to_device_email_page(self.update_job_name)
        ssot.add_and_clear_email()
        ssot.search_and_run_job(self.update_device_job)
        status = ssot.get_job_status(self.job_status_Failed)
        assert status == self.job_status_Failed, f"Expected status Failed, got {status}"
        ssot.navigate_to_device_email_page(self.update_job_name)
        ssot.delete_and_confirmation_button()
        assert self.delete in ssot.get_delete_devices_alert_text(), f"The  text is not {self.delete} as we expected."

    @pytest.mark.parametrize('test_data', ['test_run_cmdb_duplicated_device_report_job_successfully'], indirect=True)
    def test_run_cmdb_duplicated_device_report_job_successfully(self, ssot, test_data):
        """ Test to verify CMDB devices Needing duplicated report job runs successfully with correct email address"""
        ssot.search_and_run_job(self.duplicate_device_job)
        assert ssot.get_job_status(self.job_status_success) == self.job_status_success, f"Expected status Completed got \
            {self.job_status_success}"

    @pytest.mark.parametrize('test_data', ['test_add_invalid_address_cmdb_duplicated_device_job'], indirect=True)
    def test_add_invalid_address_cmdb_duplicated_device_job(self, ssot, test_data):
        """
            Test to verify add as empty address value in Ci needs duplicated report email addresses run the job and
            verify    job fails.
               Steps:
               1. Navigate to duplicated device email address page.
               2. add empty  address value
               3. Run job and verify job fails.
               4. deleted  empty address value
        """
        ssot.navigate_to_device_email_page(self.duplicate_job_name)
        ssot.add_and_clear_email()
        ssot.search_and_run_job(self.duplicate_device_job)
        status = ssot.get_job_status(self.job_status_Failed)
        assert status == self.job_status_Failed, f"Expected status Failed, got {status}"
        ssot.navigate_to_device_email_page(self.duplicate_job_name)
        ssot.delete_and_confirmation_button()
        assert self.delete in ssot.get_delete_devices_alert_text(), f"The  text is not {self.delete} as we expected."
