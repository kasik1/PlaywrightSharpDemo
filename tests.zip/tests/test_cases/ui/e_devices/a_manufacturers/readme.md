SSOT Manufacturers UI - Test Suite Folder
=============

* **Testing type:** UI Testing
* **Branch name:** F317579_US1588679_NDO_QA_NIM_update_contacts_ui

#### Folder Structure

1. **conftest.py:** Includes configuration and methods for Pytest and the test suite.
2. **rally_test_cases.csv:** File format that contains the Test Cases needed for created them in Rally.
3. **test_data.csv:** Contains the Test Data for the Tests.
4. **test_suite.py:** Script with the set of the Test Cases.

#### Documentation

For more information of this Test Suite please refer to the [Confluence Documentation] [id].

[id]: https://confluence.sys.cigna.com/pages/viewpage.action?pageId=319060840
