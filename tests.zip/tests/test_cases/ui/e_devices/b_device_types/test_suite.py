import os
import time
from tests.fixtures.users import create_login
import pytest


class DeviceType:
    def setup(self):
        self.ADD_OK = "Created device type"
        self.UPDATE = "Modified device type"
        self.ADD_URL = "/device-types/add"
        self.delete_dev_type = "Deleted device type"


@pytest.mark.parametrize('user_session', [*create_login()])
@pytest.mark.userbase
class TestDeviceTypeUserBase(DeviceType):

    @pytest.mark.parametrize('test_data', ['test_view_title_device_type'], indirect=True)
    def test_view_title_device_type(self, user_base, test_data, user_session, login_page):
        """ Tenant Group - Test check the title in the menu the tenants """
        title = 'Device Types'
        user_base.log_out()
        login_page(user_session)
        user_base.device_types_page()
        assert user_base.is_title_present(title, type='h1')
        user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_add_device_type_ub'], indirect=True)
    def test_add_device_type_ub(self, user_base, test_data, user_session, login_page):
        """ Tenant Group - Add a Device Tenant Group. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            user_base.device_types_page()
            user_base.click_add_button()
            user_base.set_device_type_data(data=row)
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_update_element_device_type'], indirect=True)
    def test_update_element_device_type(self, user_base, test_data,login_page, user_session):
        """ Tenants Group - Update a Tenant Group  with the required fields by model. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            found_contact = user_base.search_device_type(row['MODEL'])
            assert found_contact, f"No contact with name {row['MODEL']} found."
            user_base.edit_device_type(row['MODEL'], data=row)
            assert user_base.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_action_delete_device_type'], indirect=True)
    def test_action_delete_device_type(self, user_base, test_data, user_session, login_page):
        """ Tenant Group - Delete a Tenant Group type by model. """
        user_base.log_out()
        login_page(user_session)
        user_base.device_types_page()
        user_base.view_first_record_of_table()
        user_base.click_delete_button()
        user_base.log_out()


@pytest.mark.smoke
class TestDeviceTypesFormValidation:

    @pytest.mark.parametrize('test_data', ['test_search_device_type'], indirect=True)
    def test_search_device_type(self, ssot, test_data):
        """ Device Types - Search a device Types by name. """
        ssot.device_types_page()
        data = ssot.get_info_table_edit(values=["Device Type"])
        found_contact = ssot.search_device_type(data[0])
        assert found_contact, f"No contact with name {found_contact} found."


@pytest.mark.functional
class TestDeviceTypes(DeviceType):
    """Class for the devices type module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_add_device_type'], indirect=True)
    def test_add_device_type(self, ssot, test_data):
        """ Device Types - Add a Device Type. """
        for row in test_data['data']:
            ssot.add_device_type(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.ADD_OK), f"The alert text is not {self.ADD_OK} as we expected."

    @pytest.mark.parametrize('test_data', ['test_add_device_type_missing_fields'], indirect=True)
    def test_add_device_type_missing_fields(self, ssot, test_data):
        """ Device Types - Try to add a Device Type without the required fields. """
        for row in test_data['data']:
            ssot.add_device_type(data=row)
            assert ssot.check_url(self.ADD_URL), "The add alert is present."

    @pytest.mark.parametrize('test_data', ['test_view_device_type_details'], indirect=True)
    def test_view_device_type_details(self, ssot, test_data):
        """ Device Type - View Device Type details """
        for row in test_data['data']:
            found_contact = ssot.search_device_type(row['MODEL'])
            assert found_contact, f"No contact with name {row['MODEL']} found."
            ssot.click_link_text(row['MODEL'])
            assert ssot.is_present_tab_device_type('Device Type'), "The Device Type title not present in details view"
            ssot.are_device_type_stats_present()

    @pytest.mark.parametrize('test_data', ['test_view_change_log'], indirect=True)
    def test_view_change_log(self, ssot, test_data):
        """ Device Types - view the change log page"""
        for row in test_data['data']:
            found_contact = ssot.search_device_type(row['MODEL'])
            assert found_contact, f"No contact with name {row['MODEL']} found."
            ssot.click_link_text(row['MODEL'])
            ssot.go_to_tab('Change Log')
            assert ssot.is_log_table_present()

    @pytest.mark.parametrize('test_data', ['test_update_device_type'], indirect=True)
    def test_update_device_type(self, ssot, test_data):
        """ Device Types - Update a device type with the required fields by model. """
        for row in test_data['data']:
            found_contact = ssot.search_device_type(row['MODEL'])
            assert found_contact, f"No contact with name {row['MODEL']} found."
            ssot.edit_device_type(row['MODEL'], data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form'], indirect=True)
    def test_required_fields_edit_form(self, ssot, test_data):
        """ Device Types - test_load_data_edit in device type with the required fields by model. """
        ssot.device_types_page()
        data1, data2, data3 = ssot.get_info_table_edit(values=["Device Type", "Part number", "Height (U)"])
        ssot.click_link_text(data1)
        ssot.click_edit_button()
        assert ssot.get_values_form_edit(data=[data1, data2, data3]), "Required field values were not loaded correctly"

    @pytest.mark.parametrize('test_data', ['test_delete_device_type'], indirect=True)
    def test_delete_device_type(self, ssot, test_data):
        """ Device Types - Delete a device type by model. """
        for row in test_data['data']:
            found_contact = ssot.search_device_type(row['MODEL'])
            assert found_contact, f"No contact with name {row['MODEL']} found."
            ssot.delete_device_type(row['MODEL'])
            assert ssot.check_alert_text(
                self.delete_dev_type), f"The alert text is not {self.delete_dev_type} as we expected."


@pytest.mark.exports
class TestDeviceTypesExports:
    @pytest.mark.parametrize('test_data', ['test_export_device_types'], indirect=True)
    def test_export_device_types(self, ssot, test_data, rename_download):
        """ device types - export csv the current view. """
        ssot.device_types_page()
        ssot.click_export_button()
        ssot.export_current_view()

    @pytest.mark.parametrize('test_data', ['test_check_export_device_types'], indirect=True)
    def test_check_export_device_types(self, ssot, test_data, rename_download):
        """ device types - chek the csv in local machine"""
        ssot.device_types_page()
        data = ssot.get_data_for_check_export(2)
        file_name = 'device_types_export.csv'
        rename_download(name=file_name)
        file_path = os.path.join(os.getcwd(), file_name)
        assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
        csv = ssot.read_csv(file_name)
        assert ssot. check_csv_and_data(data,csv)
        os.remove(file_path)