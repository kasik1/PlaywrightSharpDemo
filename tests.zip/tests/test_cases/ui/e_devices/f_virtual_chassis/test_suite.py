import os
import time
from tests.fixtures.users import create_login
import pytest


class Virtua_Chassis:
    def setup(self):
        self.ADD_OK = "Created virtual chassis"
        self.DELETE_VIRTUAL = "Deleted"


@pytest.mark.parametrize('user_session', [*create_login()])
@pytest.mark.userbase
class TestDevicesUserBase(Virtua_Chassis):

    @pytest.mark.parametrize('test_data', ['test_view_title_virtual_chassis'], indirect=True)
    def test_view_title_virtual_chassis(self, user_base, test_data, user_session, login_page):
        """ virtual chassis - Test check the title in the menu the tenants """
        title = 'Virtual Chassis'
        user_base.log_out()
        login_page(user_session)
        user_base.virtual_chassis_page()
        assert user_base.is_title_present(title, type='h1')
        user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_add_virtual_chassis'], indirect=True)
    def test_add_virtual_chassis(self, user_base, test_data, user_session, login_page):
        """ virtual chassis - Add a Device Tenant Group. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            user_base.virtual_chassis_page()
            user_base.click_add_button()
            user_base.set_virtual_data(data=row)
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_update_element_virtual_chassis'], indirect=True)
    def test_update_element_virtual_chassis(self, user_base, test_data,login_page, user_session):
        """ virtual chassis - Update a Tenant Group  with the required fields by model. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            found_virtual = user_base.search_chassis(row['NAME'])
            assert found_virtual, f"No contact with name {row['NAME']} found."
            user_base.edit_chassis(row['NAME'], data=row)
            value = user_base.valid_update_data(data=row)
            assert value == row['NAME'], f"The alert text is not {row['NAME']} as we expected."

    @pytest.mark.parametrize('test_data', ['test_action_delete_virtual_chassis'], indirect=True)
    def test_action_delete_virtual_chassis(self, user_base, test_data, user_session, login_page):
        """ virtual chassis - Delete a Tenant Group type by model. """
        user_base.log_out()
        login_page(user_session)
        user_base.virtual_chassis_page()
        user_base.view_first_record_of_table()
        user_base.click_delete_button()
        user_base.log_out()


@pytest.mark.smoke
class TestVirtualChassisFormValidation:

    @pytest.mark.parametrize('test_data', ['test_search_virtual_chassis'], indirect=True)
    def test_search_virtual_chassis(self, ssot, test_data):
        """ Devices - Search a device by name. """
        ssot.virtual_chassis_page()
        data1 = ssot.get_info_table_edit(values=["Name"])
        found_virtual = ssot.search_chassis(data1[0])
        assert found_virtual, f"No contact with name {data1[0]} found."


@pytest.mark.parallel
@pytest.mark.functional
class TestVirtualChassis(Virtua_Chassis):
    """Class for the devices module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_add_virtual'], indirect=True)
    def test_add_virtual(self, ssot, test_data, setup_server_url):
        """ virtual chassis - Add a virtual. """
        for row in test_data['data']:
            ssot.add_virtual_chassis(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.ADD_OK), f"The alert text is not {self.ADD_OK} as we expected."

    @pytest.mark.parametrize('test_data', ['test_view_details_virtual'], indirect=True)
    def test_view_details_virtual(self, ssot, test_data):
        """ view the ditail page  in virtual chassis """
        for row in test_data['data']:
            found_virtual = ssot.search_chassis(row['NAME'])
            assert found_virtual, f"No contact with name {row['NAME']} found."
            ssot.click_text(row['NAME'])
            ssot.are_virtual_stats_present()

    @pytest.mark.parametrize('test_data', ['test_view_change_log'], indirect=True)
    def test_view_change_log(self, ssot, test_data):
        """ view the change log """
        for row in test_data['data']:
            found_virtual = ssot.search_chassis(row['NAME'])
            assert found_virtual, f"No contact with name {row['NAME']} found."
            ssot.click_text(row['NAME'])
            ssot.go_to_tab("Change Log")
            assert ssot.is_log_table_present()

    @pytest.mark.parametrize('test_data', ['test_valid_master_vs_slave'], indirect=True)
    def test_valid_master_vs_slave(self, ssot, test_data):
        """ virtual chassis - validated that the slave devices not  have  the same ip that the master. """
        for row in test_data['data']:
            found_virtual = ssot.search_chassis(row['NAME'])
            assert found_virtual, f"No contact with name {row['NAME']} found."
            ssot.click_text(row['NAME'])
            ssot.add_devices()
            ssot.set_member_add(data=row)
        ssot.return_viw_virtual()
        ssot.button_edit()
        ssot.select_master()
        ssot.view_virtual_chassis()
        val_master = ssot.get_ip_device()
        ips = []
        for element in test_data['data']:
            ssot.click_text(element['NAME_DEV'])
            ip = ssot.get_ip_device()
            ips.append(ip)
        slave = ips[:1]
        if val_master in slave:
            valid_ip = False
            return valid_ip
        else:
            valid_ip = True
            return valid_ip
        assert vlid_ip, f"the ip is repit whit the master"

    @pytest.mark.parametrize('test_data', ['test_update_chassis'], indirect=True)
    def test_update_chassis(self, ssot, test_data):
        """ chassis - Update a device with the required fields by name. """
        for row in test_data['data']:
            found_virtual = ssot.search_chassis(row['NAME'])
            assert found_virtual, f"No contact with name {row['NAME']} found."
            ssot.edit_chassis(row['NAME'], data=row)
            value = ssot.valid_update_data(data=row)
            assert value == row['NAME'], f"The alert text is not {row['NAME']} as we expected."

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form'], indirect=True)
    def test_required_fields_edit_form(self, ssot, test_data):
        """ virtual chassis  - test_load_data_edit in virtual chassis. """
        ssot.virtual_chassis_page()
        data = ssot.get_info_table_edit(values=["Name"])
        ssot.click_link_text(data[0])
        ssot.click_edit_button()
        input_values = ssot.get_input_values_form_edit(['Name'])
        assert all(element in data for element in input_values), "in the edit view the required" \
                                                                   " fields were not loaded, and the " \
                                                                   "assert fails because it cannot " \
                                                                   "find the value in the form"

    @pytest.mark.parametrize('test_data', ['test_delete_virtual'], indirect=True)
    def test_delete_virtual(self, ssot, test_data):
        """ virtual chassis  - Delete a virtual chassis by name. """
        for row in test_data['data']:
            found_virtual = ssot.search_chassis(row['NAME'])
            assert found_virtual, f"No contact with name {row['NAME']} found."
            ssot.delete_virtual_chassis(row['NAME'])
            assert ssot.check_alert_text(self.DELETE_VIRTUAL), f"The alert text is git not {self.DELETE_VIRTUAL} as we expected."


@pytest.mark.exports
class TestVirtualChassisExports:
    @pytest.mark.parametrize('test_data', ['test_export_virtual_chassis'], indirect=True)
    def test_export_virtual_chassis(self, ssot, test_data, rename_download):
        """ virtual chassis - export csv the current view. """
        ssot.virtual_chassis_page()
        ssot.click_export_button()
        ssot.export_current_view()

    @pytest.mark.parametrize('test_data', ['test_check_export_virtual_chassis'], indirect=True)
    def test_check_export_virtual_chassis(self, ssot, test_data, rename_download):
        """ virtual chassis - chek the csv in local machine"""
        ssot.virtual_chassis_page()
        data = ssot.get_data_for_check_export(2)
        file_name = 'virtual_export.csv'
        rename_download(name=file_name)
        file_path = os.path.join(os.getcwd(), file_name)
        assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
        csv = ssot.read_csv(file_name)
        assert ssot. check_csv_and_data(data,csv)
        os.remove(file_path)