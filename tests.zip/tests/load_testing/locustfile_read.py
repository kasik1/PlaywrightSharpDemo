from os import environ

from locust import HttpUser, between, task
from pyquery import PyQuery


class SsotRead(HttpUser):
    host = "http://cvlappxd33549.silver.com:8080"

    # we assume someone who is browsing the Locust docs,
    # generally has a quite long waiting time (between
    # 5 and 20 seconds), since there's a bunch of text
    # on each page
    wait_time = between(5, 20)

    def on_start(self):
        self.login()

    def on_stop(self):
        self.logout()

    def login(self):
        self.client.verify = False
        base_page = self.client.get('')
        self.client.headers['Referer'] = self.client.base_url
        index_page = self.client.post('/login/admin',
                      {'username': environ['ssot_username'], 'password': environ['ssot_password'],
                       'csrfmiddlewaretoken': base_page.cookies['csrftoken']})

    def logout(self):
        self.client.get("/logout/")

    @task(3)
    def loding_page(self):
        request = self.client.get("/")
        cont = PyQuery(request.content)
        link_elements = cont(".navbar-brand span")
        link_elements = link_elements.text()
        assert "SSOT" in link_elements

    @task(3)
    def index_page(self):
        endpoint = '/'
        request = self.client.get(endpoint)
        content = PyQuery(request.content)

    @task(3)
    def menu(self):
        endpoint = '/'
        request = self.client.get(endpoint)
        content = PyQuery(request.content)
        nav_var = content("li.dropdown a")
        self.toc_urls = [
            l.attrib["href"] for l in nav_var
        ]

    @task(3)
    def search_element(self):
        endpoint = '/search/'
        request = self.client.get(endpoint + '?q=device&obj_type=')
        content = PyQuery(request.content)
        request_search = content(".panel-heading")
        request_search = request_search.text()
        assert "Search Results" in request_search

    @task(3)
    def search_element_not_found(self):
        endpoint = '/search/'
        request = self.client.get(endpoint + '?q=ssot&obj_type=')
        content = PyQuery(request.content)
        request_search = content(".text-muted.text-center")
        request_search = request_search.text()
        assert "No results found" in request_search

    @task(3)
    def get_site(self):
        endpoint = "/api/dcim/sites/"
        request = self.client.get(endpoint)
        property = request.json()["results"][0]["property_id"]
        if property != " ":
            endpoint = "/dcim/sites/"
            self.client.get(endpoint + property)

    @task(3)
    def get_devices(self):
        endpoint = "/api/dcim/devices/"
        request = self.client.get(endpoint)
        object_id = request.json()["results"][0]["id"]
        if object_id != " ":
            endpoint = "/dcim/devices/"
            self.client.get(endpoint + str(object_id))

    @task(3)
    def get_contacts(self):
        endpoint = "/api/ndo/contacts/"
        request = self.client.get(endpoint)
        object_id = request.json()["results"][0]["slug"]
        if object_id != " ":
            endpoint = "/ndo/contacts/"
            self.client.get(endpoint + str(object_id))
