from ..commons.csv import Csv
import requests
import os
import json


def users():
    """
    Returns the users credentials for testing from a csv file
    """
    #return
    path = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(path, 'users.csv')
    csv_file = Csv(file_path)
    return [row for row in csv_file.rows()]


def create_sessions():
    sessions = []
    for user in users():
        session = requests.Session()
        session.verify = False
        session.auth = (user['username'], user['password'])
        cookie_obj = requests.cookies.create_cookie(name="user_group", value=json.dumps(user['user_group']))
        session.cookies.set_cookie(cookie_obj)
        sessions.append(session)
    return sessions


def user_has_permissions(user_groups, application):
    """
    Check is the user has access to a module through his groups
    :param user_groups: The groups that a user has
    :param application: The module from the Portal that is being tested
    """
    results =users()
    if application in results:
        if any(item in user_groups for item in results[application]):
            return True
    return False


def create_login():
    user_name = []
    for user in users():
        user_name.append(dict(USER=user['username'], PASSWORD=user['password']))
    return user_name
