from ..commons.django_api_config import get_project_credentials
import requests
import pytest
import json
import urllib3
urllib3.disable_warnings(category=urllib3.exceptions.InsecureRequestWarning)

@pytest.fixture(scope='session')
def session():
    def _session(usern='', passwd='', project='DJANGO'):
        with requests.Session() as session:
            session.verify = False

            if usern != '' and passwd != '':
                session.auth = (usern, passwd)

            elif usern == 'NOUSERNAME':
                return session
            else:
                username, password = get_project_credentials(project)
                session.auth = (username, password)
            return session
    return _session


@pytest.fixture
def response_asserts(ndo_logger):
    """This fixture do the respective asserts to be sure that the responses are correct."""
    def _response_asserts(response, status_code=200, content_type='application/json', ok=True, assert_json=True,
                          assert_content_type=True):
        ndo_logger.debug("")
        ndo_logger.debug("============================== RESPONSE ASSERTS ==============================")
        ndo_logger.debug(f'Response Status code: {response.status_code}')
        ndo_logger.debug(f'Response OK: {response.ok}')

        assert response.status_code == status_code, 'Status code is different from expected'
        if assert_content_type:
            ndo_logger.debug(f"Response Content-type: {response.headers['Content-type']}")
            assert response.headers['Content-type'] == content_type, 'Content-type is different from expected'
        assert response.ok == ok, 'Response OK is different from expected'

        if assert_json:
            assert response.json() == json.loads(response.content), 'Response from request is not a JSON response'
    return _response_asserts


@pytest.fixture
def response_results(ndo_logger):
    """This fixture write in the live logs the response for a request."""

    def print_json_response(print_json_rows, response):
        """Function to print the Response.json()"""
        try:
            ndo_logger.debug("")
            ndo_logger.debug("==============================  JSON RESPONSE ==============================")
            json_response = response.json()
            if print_json_rows:
                for result in json_response:
                    ndo_logger.debug(result)
            else:
                ndo_logger.debug(json_response)
        except ValueError:
            ndo_logger.error(response.text)
            ndo_logger.error('Error at JSON result: JSON response was expected but it failed')

    def _response_results(response, print_json=True, print_content_type=True, print_json_rows=True):
        """
        :param response: Request response
        :param print_json: Indicates to print a json
        :param print_content_type: Indicates to print the content-type
        :param print_json_rows: Indicates if a json should be iterated to be printed
        """

        ndo_logger.debug("")
        ndo_logger.debug("============================== RESPONSE RESULTS ==============================")
        ndo_logger.info(f'Request URL: {response.url}')
        ndo_logger.debug(f"Status code: {response.status_code}")
        ndo_logger.debug(f"Headers: {response.headers}")
        ndo_logger.debug(f"Response ok: {response.ok}")

        if print_content_type:
            ndo_logger.debug(f"Content-Type: {response.headers['Content-Type']}")

        if print_json:
            print_json_response(print_json_rows, response)

    return _response_results


@pytest.fixture
def response_assert_fields():
    """This fixture write in the live logs the response assertions for a specific field."""
    def assert_field_in_dict(response, field):
        if type(response) == list:
            for list_element in response:
                assert_field_in_dict(list_element, field)
        elif type(response) == dict:
            assert field in response, 'Field \'{}\' does not exist in the response'.format(field)

    def _response_assert_fields(response, fields, search_in_results=False):
        json_response = response.json()

        if search_in_results:
            for field in fields:
                assert_field_in_dict(json_response['results'], field)
        else:
            for field in fields:
                assert_field_in_dict(json_response, field)
    return _response_assert_fields
