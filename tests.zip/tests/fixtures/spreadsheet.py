from ..commons.functions import fill_test_case_detail_values
import pytest


@pytest.fixture
def test_data(request, excel):
    fixture_name = request.param
    data = {
        'test_case': {
            'test_case_id': '',
            'build': '',
            'tester': '',
            'notes': '',
            'c_environment': ''},
        'data': []
    }
    for row in (row for row in excel.rows() if row['TEST_TYPE'] == fixture_name):
        data = fill_test_case_detail_values(data, row)
        data['data'].append(row)
    return data
