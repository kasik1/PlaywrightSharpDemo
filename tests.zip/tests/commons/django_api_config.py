# from ndosecrets import get_secret,get_local_secret
#
# try:
#     from ..commons.credentials import \
#         portal_username, portal_password, \
#         servicenow_username, servicenow_password
# except:
#     pass
#
# NAUTOBOT_ENVIRONMENT = get_local_secret("environment")
# VAULT_SETTINGS = get_secret(f"ssot/environment/{NAUTOBOT_ENVIRONMENT}")
#
#
# def get_project_credentials(project_name='DJANGO'):
#     """work around until the secrets library is fully integrated"""
#     try:
#         username = VAULT_SETTINGS.get("testing_username")
#         password = VAULT_SETTINGS.get("testing_password")
#
#         return username, password
#     except:
#         raise Exception("Error on Credentials retrieval")
try:
    from ..commons.credentials import \
        portal_username, portal_password, \
        servicenow_username, servicenow_password
except:
    pass

from ..commons.credentials import nim_username, nim_password


def get_project_credentials(project_name='DJANGO'):
    if project_name == 'DJANGO':
        username = nim_username
        password = nim_password
    return username, password