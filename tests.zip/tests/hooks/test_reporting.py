from .style import style, modal
from datetime import datetime
from py.xml import html, raw
import pytest
import os
from ..fixtures.users import user_has_permissions


def get_test_folder_type(nodeid):
    sections = nodeid.split('::')
    sections_aux = sections[0].split('/')
    return sections_aux[0]


def get_screenshot_file_name(nodeid):
    sections = nodeid.split('::')
    sections_aux = sections[0].split('/')
    node = f'{sections_aux[0]}_{sections_aux[1]}'
    test_case_name = sections[2].split('[')[0]
    name = node + '_' + test_case_name + '.png'
    return name


def format_time_duration(time):
    """
    Minutes should be multiply by 1000 e.g. 60 * 1000
    Seconds should be multiply by 1000 e.g. 1 * 1000
    Miliseconds should not be multiply
    :param time: Float duration time
    :return:
    """
    time_float = round(float(time), 2)
    time_str = str(time_float)

    minutes = int(time) / 60
    minutes_rounded = round(minutes)
    if minutes_rounded > 0:
        minutes = (minutes_rounded * 60) * 1000

    seconds = int(time % 60)
    seconds = seconds * 1000

    milliseconds = int(time_str.split('.')[1])

    final_time = minutes + seconds + milliseconds
    return int(final_time)


def get_test_case_info_for_report(item, report):
    """
    :param item: Test item from the current test case execution
    :return: returns the information of the Test Case
    """
    tc_info = {
        'test_case_id': '',
        'build': '',
        'notes': '',
        'duration': 0.0,
        'tester': '',
        'c_environment': '',
        'test_type': '',
        'test_case_name': '',
        'application': '',
        'classification': '',
        'workspace': '',
    }

    for field in tc_info:
        if field == 'build':  # Gets the build or branch in order to label the execution
            if item.config.option.branch is not None:
                build = item.config.option.branch
            else:
                build = item.funcargs['test_data']['test_case'][field]
            tc_info[field] = build
        elif field == 'test_type':
            aux = str(item.cls)
            if '.api.' in aux:
                tc_info[field] = 'api'
            if '.ui.' in aux:
                tc_info[field] = 'ui'

        elif field == 'test_case_name':
            tc_info[field] = item.originalname

        elif field == 'duration':
            tc_info[field] = format_time_duration(report.duration)

        elif field == 'application':
            tc_info[field] = item.nodeid.split('/')[1]

        elif field == 'classification':
            tc_info[field] = item.cls.pytestmark[0].name

        elif field == 'workspace':
            if item.config.option.workspace is not None:
                workspace = item.config.option.workspace
                name = workspace.split('/')[-1]
                tc_info[field] = f'{name}_{item.config.option.build}'

        else:  # Gets the other fields from the test case
            tc_info[field] = item.funcargs['test_data']['test_case'][field]
    return tc_info


def format_tc_info_for_splunk(tc_info, item, verdict, notes):
    """
    :param tc_info: Test Case information
    :param item: Test item from the current test case execution
    :param verdict: Verdict of the test case result e.g. pass or fail
    :param notes: Notes or description of the test case
    """
    tc_info['verdict'] = verdict
    tc_info['notes'] += notes

    if tc_info['test_case_name'] != '':
        date = datetime.now().isoformat()
        test_case_results = {
            'tc_id': tc_info['test_case_id'],
            'tc_name': tc_info['test_case_name'],
            'tc_build': tc_info['build'],
            'tc_creation': date,
            'tc_duration': tc_info['duration'],
            'tc_verdict': verdict,
            'tc_tester': tc_info['tester'],
            'tc_type': tc_info['test_type'],
            'tc_notes': tc_info['notes'],
            'tc_application': tc_info['application'],
            'tc_classification': tc_info['classification'],
            'tc_workspace': tc_info['workspace'],
        }

        if len(item.config.args) == 1:
            item.config.args.append({'test_case_results': []})
        item.config.args[1]['test_case_results'].append(test_case_results)


def pytest_html_results_summary(prefix, summary, postfix):
    """
    Add the html modal and add a style tag for the modal
    """
    prefix.extend([
        html.style(style),
        raw(modal)])

def pytest_html_report_title(report):
   report.title = "Test Execution Results"


def pytest_html_results_table_header(cells):
    cells.insert(2, html.th('Description'))
    cells.insert(4, html.th('Server'))
    cells.insert(5, html.th('app', class_='sortable', col='app'))
    cells.insert(6, html.th('code', class_='sortable', col='code'))
    cells.pop()


def pytest_html_results_table_row(report, cells):
    try:
        description = report.description
        server = report.server
    except Exception:
        description = ''
        server = ''
    test_path = report.nodeid.encode("utf-8").decode("unicode_escape")
    code, app = test_path.split("/")[:2]
    cells.insert(2, html.td(description))
    cells.insert(4, html.td(html.a(server, href=server)))
    cells.insert(5, html.td(code))
    cells.insert(6, html.td(app))
    cells.pop()


def attach_screenshot(item, report, extra, pytest_html):
    name = get_screenshot_file_name(item.nodeid)
    extra.append(pytest_html.extras.html(
        f'<div class="image"><img class="myImages" id="myImg" src="screenshots/{name}"/></div>'))
    report.extra = extra
    return report


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_makereport(item, call):
    pytest_html = item.config.pluginmanager.getplugin('html')
    outcome = yield
    report = outcome.get_result()
    extra = getattr(report, 'extra', [])
    verdict = 'Fail'
    notes = ''

    # Extra fields for the html report
    if item.funcargs != {} and 'test_data' in item.funcargs:
        test_case_description = item.funcargs['test_data']['test_case']['notes']
        test_server_url = item.funcargs['setup_server_url']
        report.description = test_case_description

    # Take a screenshot if test case setup fails
    if call.when == 'setup':
        if report.failed:
            if get_test_folder_type(item.nodeid) == 'ui':
                if call.excinfo.typename != 'WebDriverException':
                    take_screenshot(item.funcargs['global_driver'], item.nodeid)
                    report = attach_screenshot(item, report, extra, pytest_html)

    if call.when == 'call':

        # If user based test cases are being run
        if 'user_session' in item.fixturenames:
            user_group = item.funcargs['test_data']['test_case']['user_group']
            test_path = report.nodeid.encode("utf-8").decode("unicode_escape")
            code, application = test_path.split("/")[:2]
            has_permissions = user_has_permissions(user_group, application)
            if not has_permissions and report.outcome == 'failed':
                report.outcome = 'failed'
            elif not has_permissions and report.outcome == 'passed':
                report.outcome = 'passed'

        # Get the fields and values from the test_data fixture
        tc_info = get_test_case_info_for_report(item, report)

        # Save the result and notes of the test case execution
        if report.failed:
            verdict = 2  # Fail
            notes = '\nTest Case {}::{} failed.'.format(item.location[0], item.location[2])
            if call.excinfo is not None:
                notes += '\nDetails: ' + str(call.excinfo.value)

            # If a UI Test Case fails then take a screenshot and add it to the hmlt report
            if get_test_folder_type(item.nodeid) == 'ui':
                report = attach_screenshot(item, report, extra, pytest_html)

        if report.passed:
            verdict = 1  # Pass
            notes = '\nTest Case {}::{} passed.'.format(item.location[0], item.location[2])

        # Save test case info in item.config.args
        format_tc_info_for_splunk(tc_info, item, verdict, notes)

    if call.when == 'teardown':
        try:
            setattr(report, "error_traceback", item.error_traceback)
        except:
            setattr(report, "error_traceback", '')

    setattr(item, "rep_" + report.when, report)
    return report


@pytest.fixture(scope="function", autouse=True)
def test_failed_check(request):
    """
    Check if a test has failed
    :param request: pytest's request object
    """
    yield
    nodeid = request.node.nodeid
    if get_test_folder_type(nodeid) == 'ui':
        if request.node.rep_setup.passed:
            if request.node.rep_call.failed:
                driver = request.node.funcargs.get('global_driver', False)
                if not driver:
                    driver = request.node.funcargs.get('user_base_driver')
                take_screenshot(driver, request.node.nodeid)


def take_screenshot(driver, nodeid):
    """
    Take a screenshot using the Selenium Driver
    :param driver: The Selenium Driver instance
    :param nodeid: The path of the test case that is being executed
    """
    # file_name = get_screenshot_file_name(nodeid)
    # driver.save_screenshot(f'{file_name}')
    file_name = get_screenshot_file_name(nodeid)
    driver.save_screenshot(f'/opt/nautobot/nautobot/test_results/screenshots/{file_name}')